import {createRequire} from 'node:module';
import {tmpdir} from 'node:os';
import {mkdtemp, readFile, rm} from 'node:fs/promises';
import {describe, it, expect, vi, beforeEach} from 'vitest';
import {writeFile, fileExists} from '@shopify/cli-kit/node/fs';
import {joinPath} from '@shopify/cli-kit/node/path';
import {
  renderSelectPrompt,
  renderConfirmationPrompt,
  renderTasks,
  renderInfo,
} from '@shopify/cli-kit/node/ui';
import {mockAndCaptureOutput} from '@shopify/cli-kit/node/testing/output';
import {type PackageJson} from '@shopify/cli-kit/node/node-package-manager';
import {exec} from '@shopify/cli-kit/node/system';
import {
  buildUpgradeCommandArgs,
  displayConfirmation,
  generateUpgradeInstructionsFile,
  getAbsoluteVersion,
  getAvailableUpgrades,
  getCumulativeRelease,
  getHydrogenVersion,
  getPackageVersion,
  getSelectedRelease,
  validateUpgrade,
  runUpgrade,
  type CumulativeRelease,
  type Release,
  upgradeNodeModules,
  getChangelog,
  displayDevUpgradeNotice,
} from './upgrade.js';
import {getSkeletonSourceDir} from '../../lib/build.js';

// Test version numbers used to avoid conflicts with duplicate changelog versions
const TEST_VERSION_DEPENDENCY_UPGRADE = '9999.99.99';
const TEST_VERSION_DEV_DEPENDENCY_UPGRADE = '9999.99.98';

vi.mock('@shopify/cli-kit/node/session');
vi.mock('@shopify/cli-kit/node/node-package-manager', async () => {
  const original = await vi.importActual<
    typeof import('@shopify/cli-kit/node/node-package-manager')
  >('@shopify/cli-kit/node/node-package-manager');
  return {
    ...original,
    getPackageManager: vi.fn(() => Promise.resolve('pnpm')),
  };
});

vi.mock('../../lib/shell.js', () => ({getCliCommand: vi.fn(() => 'h2')}));

vi.mock('@shopify/cli-kit/node/ui', async () => {
  const original = await vi.importActual<
    typeof import('@shopify/cli-kit/node/ui')
  >('@shopify/cli-kit/node/ui');

  return {
    ...original,
    renderTasks: vi.fn(() => Promise.resolve()),
    renderSelectPrompt: vi.fn(() => Promise.resolve()),
    renderConfirmationPrompt: vi.fn(() => Promise.resolve(false)),
    renderInfo: vi.fn(original.renderInfo),
  };
});

const outputMock = mockAndCaptureOutput();

beforeEach(() => {
  vi.restoreAllMocks();
  vi.resetModules();
  vi.clearAllMocks();
  outputMock.clear();
});

async function createOutdatedSkeletonPackageJson() {
  const require = createRequire(import.meta.url);
  const packageJson: PackageJson = require(
    joinPath(getSkeletonSourceDir(), 'package.json'),
  );

  if (!packageJson) throw new Error('Could not parse package.json');
  if (!packageJson?.dependencies)
    throw new Error('Could not parse package.json dependencies');
  if (!packageJson?.devDependencies)
    throw new Error('Could not parse package.json devDependencies');

  // bump the versions to be outdated
  packageJson.dependencies['@shopify/hydrogen'] = '^2023.1.6';
  packageJson.dependencies['@remix-run/react'] = '1.12.0';
  packageJson.devDependencies['@shopify/cli-hydrogen'] = '^4.0.8';
  packageJson.devDependencies['@shopify/remix-oxygen'] = '^1.0.3';
  packageJson.devDependencies['@remix-run/dev'] = '1.12.0';
  packageJson.devDependencies['typescript'] = '^4.9.5';

  return packageJson;
}

async function createOutdatedSkeletonPackageJsonWithReactRouter() {
  const require = createRequire(import.meta.url);
  const packageJson: PackageJson = require(
    joinPath(getSkeletonSourceDir(), 'package.json'),
  );

  if (!packageJson) throw new Error('Could not parse package.json');
  if (!packageJson?.dependencies)
    throw new Error('Could not parse package.json dependencies');
  if (!packageJson?.devDependencies)
    throw new Error('Could not parse package.json devDependencies');

  // bump the versions to be outdated
  packageJson.dependencies['@shopify/hydrogen'] = '^2023.1.6';
  packageJson.dependencies['react-router'] = '7.0.0';
  packageJson.dependencies['react-router-dom'] = '7.0.0';
  packageJson.devDependencies['@shopify/cli-hydrogen'] = '^4.0.8';
  packageJson.devDependencies['@shopify/remix-oxygen'] = '^1.0.3';
  packageJson.devDependencies['@react-router/dev'] = '7.0.0';
  packageJson.devDependencies['typescript'] = '^4.9.5';

  return packageJson;
}

async function createPreMigrationPackageJson() {
  const require = createRequire(import.meta.url);
  // Deep clone to avoid mutating the require() cache, which is shared
  // across all createXxx helpers in this file.
  const packageJson: PackageJson = JSON.parse(
    JSON.stringify(require(joinPath(getSkeletonSourceDir(), 'package.json'))),
  ) as PackageJson;

  if (!packageJson) throw new Error('Could not parse package.json');
  if (!packageJson?.dependencies)
    throw new Error('Could not parse package.json dependencies');
  if (!packageJson?.devDependencies)
    throw new Error('Could not parse package.json devDependencies');

  // Pin to pre-React Router migration version so the upgrade to 2025.7.0 triggers cumulative removals
  packageJson.dependencies['@shopify/hydrogen'] = '~2025.5.1';
  packageJson.dependencies['@remix-run/react'] = '^2.0.0';
  packageJson.dependencies['@remix-run/server-runtime'] = '^2.0.0';
  packageJson.devDependencies['@shopify/remix-oxygen'] = '^2.0.0';
  packageJson.devDependencies['@remix-run/dev'] = '^2.0.0';

  return packageJson;
}

const REACT_ROUTER_RELEASE = {
  title: 'React Router 7.5',
  version: '2025.5.0',
  hash: '-',
  commit: 'https://github.com/Shopify/hydrogen/pull/2819',
  pr: 'https://github.com/Shopify/hydrogen/pull/2819',
  dependencies: {
    'react-router': '^7.5.0',
    '@shopify/hydrogen': '2025.5.0',
    '@shopify/remix-oxygen': '^2.0.12',
  },
  devDependencies: {
    '@react-router/dev': '^7.5.0',
    '@shopify/cli': '3.77.1',
    '@shopify/mini-oxygen': '^3.2.0',
    '@shopify/hydrogen-codegen': '^0.3.3',
    '@shopify/oxygen-workers-types': '^4.1.6',
    vite: '^6.2.4',
  },
  dependenciesMeta: {},
  fixes: [],
  features: [],
  date: '2025-04-24',
} satisfies Release;

/**
 * Creates a temporary directory in OS temp (not in repo)
 */
async function inTemporaryDirectory(cb: (tmpDir: string) => Promise<void>) {
  const tmpDir = await mkdtemp(joinPath(tmpdir(), 'hydrogen-test-'));

  try {
    await cb(tmpDir);
  } finally {
    await rm(tmpDir, {recursive: true, force: true});
  }
}

/**
 * Creates a temporary directory in OS temp (not in repo) with a git repo and a package.json
 */
async function inTemporaryHydrogenRepo(
  cb: (tmpDir: string) => Promise<void>,
  {
    cleanGitRepo,
    packageJson,
  }: {
    cleanGitRepo?: boolean;
    packageJson?: PackageJson;
  } = {cleanGitRepo: true},
) {
  // Create temp directory in OS temp folder, not in the repo
  const tmpDir = await mkdtemp(joinPath(tmpdir(), 'hydrogen-test-'));

  try {
    // init the git repo
    await exec('git', ['init'], {cwd: tmpDir});

    if (packageJson) {
      const packageJsonPath = joinPath(tmpDir, 'package.json');
      await writeFile(packageJsonPath, JSON.stringify(packageJson));
      expect(await fileExists(packageJsonPath)).toBeTruthy();
    }

    // expect to be a git repo
    expect(await fileExists(joinPath(tmpDir, '/.git/config'))).toBeTruthy();

    if (cleanGitRepo) {
      await exec('git', ['add', 'package.json'], {cwd: tmpDir});

      if (process.env.SHOPIFY_UNIT_TEST || process.env.CI) {
        await exec(
          'git',
          ['config', '--local', 'user.email', 'test@hydrogen.shop'],
          {
            cwd: tmpDir,
          },
        );
        await exec('git', ['config', '--local', 'user.name', 'Hydrogen Test'], {
          cwd: tmpDir,
        });
      }
      await exec('git', ['commit', '-m', 'initial commit'], {cwd: tmpDir});
    }

    await cb(tmpDir);
  } finally {
    // Clean up: remove the temporary directory
    await rm(tmpDir, {recursive: true, force: true});
  }
}

function increasePatchVersion(depName: string, deps: Record<string, string>) {
  const depVersion = deps[depName];
  if (!depVersion) {
    throw new Error(
      `No dependency "${depName}" found in: ${Object.keys(deps || {})}`,
    );
  }

  return {
    [depName]: depVersion.replace(
      /\.(\d+)$/,
      (_, patchVersion) => `.${Number(patchVersion) + 1}`,
    ),
  };
}

describe('upgrade', async () => {
  // Create an outdated skeleton package.json for all tests
  const OUTDATED_HYDROGEN_PACKAGE_JSON =
    await createOutdatedSkeletonPackageJson();

  const OUTDATED_HYDROGEN_PACKAGE_JSON_WITH_REACT_ROUTER =
    await createOutdatedSkeletonPackageJsonWithReactRouter();

  const PRE_MIGRATION_PACKAGE_JSON = await createPreMigrationPackageJson();

  describe('checkIsGitRepo', () => {
    it('renders an error message when not in a git repo', async () => {
      await inTemporaryDirectory(async (appPath) => {
        await expect(runUpgrade({appPath})).rejects.toThrowError(
          'git repository',
        );
      });
    });
  });

  describe('checkDirtyGitBranch', () => {
    it('renders error message if the target git repo is dirty', async () => {
      await inTemporaryHydrogenRepo(
        async (appPath) => {
          await expect(runUpgrade({appPath})).rejects.toThrowError('clean git');
        },
        {cleanGitRepo: false, packageJson: OUTDATED_HYDROGEN_PACKAGE_JSON},
      );
    });
  });

  describe('getHydrogenVersion', () => {
    it('throws if no package.json is found', async () => {
      await inTemporaryHydrogenRepo(
        async (appPath) => {
          await expect(runUpgrade({appPath})).rejects.toThrowError(
            'valid package.json',
          );
        },
        {packageJson: undefined},
      );
    });

    it('throws if no hydrogen version is found in package.json', async () => {
      await inTemporaryHydrogenRepo(
        async (appPath) => {
          await expect(runUpgrade({appPath})).rejects.toThrowError(
            'version in package.json',
          );
        },
        {
          cleanGitRepo: true,
          packageJson: {
            name: 'some-name',
            dependencies: {},
          },
        },
      );
    });

    it('returns the current hydrogen version from the package.json', async () => {
      await inTemporaryHydrogenRepo(
        async (appPath) => {
          const hydrogen = await getHydrogenVersion({appPath});

          expect(hydrogen).toBeDefined();
          expect(hydrogen.currentVersion).toMatch('^2023.1.6');
          expect(hydrogen.currentDependencies).toMatchObject({
            ...OUTDATED_HYDROGEN_PACKAGE_JSON.dependencies,
            ...OUTDATED_HYDROGEN_PACKAGE_JSON.devDependencies,
          });
        },
        {
          cleanGitRepo: true,
          packageJson: OUTDATED_HYDROGEN_PACKAGE_JSON,
        },
      );
    });

    it('exists when run over a prerelease "next" version', async () => {
      await inTemporaryHydrogenRepo(
        async (appPath) => {
          await expect(runUpgrade({appPath})).rejects.toThrowError(
            'prerelease',
          );
        },
        {
          cleanGitRepo: true,
          packageJson: {
            dependencies: {
              '@shopify/hydrogen': '0.0.0-next-74ea1db-20231120210149',
            },
          },
        },
      );
    });
  });

  describe('fetchChangelog', () => {
    it('fetches the latest changelog from the hydrogen repo', async () => {
      // Force remote changelog usage by clearing local environment
      const originalForceLocal = process.env.FORCE_CHANGELOG_SOURCE;
      process.env.FORCE_CHANGELOG_SOURCE = 'remote';

      try {
        const changelog = await getChangelog();

        // Verify changelog structure
        expect(changelog).toBeDefined();
        expect(changelog).toHaveProperty('url');
        expect(changelog).toHaveProperty('version');
        expect(changelog).toHaveProperty('releases');

        // Verify URL points to GitHub pulls
        expect(changelog.url).toMatch(/github\.com\/Shopify\/hydrogen/);

        // Verify releases array structure
        expect(Array.isArray(changelog.releases)).toBe(true);
        expect(changelog.releases.length).toBeGreaterThan(0);

        // Verify first release has required fields
        const latestRelease = changelog.releases[0];
        expect(latestRelease).toBeDefined();

        if (!latestRelease) {
          throw new Error('Latest release is undefined');
        }

        expect(latestRelease).toHaveProperty('title');
        expect(latestRelease).toHaveProperty('version');
        expect(latestRelease).toHaveProperty('hash');
        expect(latestRelease).toHaveProperty('commit');
        expect(latestRelease).toHaveProperty('dependencies');
        expect(latestRelease).toHaveProperty('features');
        expect(latestRelease).toHaveProperty('fixes');

        // Verify version format (YYYY.M.P)
        expect(latestRelease.version).toMatch(/^\d{4}\.\d+\.\d+$/);

        // Verify commit URL format
        expect(latestRelease.commit).toMatch(
          /^https:\/\/github\.com\/Shopify\/hydrogen/,
        );

        // Verify dependencies are objects
        expect(typeof latestRelease.dependencies).toBe('object');
        if (latestRelease.devDependencies !== undefined) {
          expect(typeof latestRelease.devDependencies).toBe('object');
        }

        // Verify features and fixes are arrays
        expect(Array.isArray(latestRelease.features)).toBe(true);
        expect(Array.isArray(latestRelease.fixes)).toBe(true);
      } finally {
        // Restore original environment
        if (originalForceLocal !== undefined) {
          process.env.FORCE_CHANGELOG_SOURCE = originalForceLocal;
        } else {
          delete process.env.FORCE_CHANGELOG_SOURCE;
        }
      }
    }, 10000); // 10 second timeout for network call

    it('successfully loads changelog when network is available', async () => {
      // This test validates that the changelog function works as expected
      // Both local and remote sources should provide valid changelog data
      const changelog = await getChangelog();

      // Test core functionality
      expect(changelog.releases).toBeDefined();
      expect(changelog.releases.length).toBeGreaterThan(0);

      // Test that releases have the expected structure
      const sampleRelease = changelog.releases[0];
      expect(sampleRelease).toBeDefined();

      if (!sampleRelease) {
        throw new Error('Sample release is undefined');
      }

      expect(sampleRelease.version).toBeDefined();
      expect(sampleRelease.dependencies).toBeDefined();

      // Test that the structure matches what upgrade functions expect
      expect(typeof sampleRelease.dependencies).toBe('object');
      if (sampleRelease.devDependencies !== undefined) {
        expect(typeof sampleRelease.devDependencies).toBe('object');
      }
      expect(Array.isArray(sampleRelease.features)).toBe(true);
      expect(Array.isArray(sampleRelease.fixes)).toBe(true);
    });
  });

  describe('getAvailableUpgrades', async () => {
    it('renders "already in the latest version" success message if no upgrades are available', async () => {
      const {releases} = await getChangelog();

      await inTemporaryHydrogenRepo(
        async (appPath) => {
          await runUpgrade({appPath});
          expect(outputMock.info()).toMatch(
            / success.+ latest Hydrogen version/is,
          );
        },
        {
          cleanGitRepo: true,
          packageJson: {
            dependencies: {
              // @ts-expect-error - we know this release version exists
              '@shopify/hydrogen': releases[0].version,
            },
          },
        },
      );
    });

    it('returns available upgrades and uniqueAvailableUpgrades if they exist', async () => {
      const {releases} = await getChangelog();

      await inTemporaryHydrogenRepo(
        async (appPath) => {
          const current = await getHydrogenVersion({appPath});
          const result = getAvailableUpgrades({
            releases,
            ...current,
          });

          // The getAvailableUpgrades function should:
          // 1. Return all releases newer than the current version
          // 2. Filter out duplicate versions (keeping only the first/newest)
          //
          // To make this test resilient to both duplicate and unique versions,
          // we need to find the first set of unique versions that are newer
          // than what's installed (releases[2].version)

          // Find up to 2 unique versions that are newer than releases[2]
          const newerReleases = [];
          const seenVersions = new Set();

          for (const release of releases) {
            // Stop when we reach the installed version
            if (release.version === releases[2]?.version) break;

            // Only add if we haven't seen this version
            if (!seenVersions.has(release.version)) {
              newerReleases.push(release);
              seenVersions.add(release.version);
              // Stop after finding 2 unique versions
              if (newerReleases.length >= 2) break;
            }
          }

          // Build expected uniqueAvailableUpgrades
          const expectedUniqueUpgrades = newerReleases.reduce(
            (acc, release) => {
              return {
                ...acc,
                [release.version]: release,
              };
            },
            {},
          );

          // Verify the results
          expect(result.availableUpgrades).toHaveLength(newerReleases.length);
          expect(result.availableUpgrades).toEqual(newerReleases);
          expect(result.uniqueAvailableUpgrades).toEqual(
            expectedUniqueUpgrades,
          );
        },
        {
          cleanGitRepo: true,
          packageJson: {
            dependencies: {
              // Install an older version (3rd in the list)
              '@shopify/hydrogen': releases[2]!.version,
            },
          },
        },
      );
    });

    it('reports no upgrade when current dependencies match latest', async () => {
      const {releases} = await getChangelog();
      const latestRelease = releases[0]!;
      const releasesFromLatest = releases;

      expect(
        getAvailableUpgrades({
          currentVersion: latestRelease.version,
          currentDependencies: {},
          releases: releasesFromLatest,
        }).availableUpgrades,
      ).toHaveLength(0);
    });

    it('finds upgrade when a dependency has a higher patch version', async () => {
      const {releases} = await getChangelog();
      const releaseWithDeps = releases.find(
        (r) => r.dependencies && Object.keys(r.dependencies).length > 0,
      );
      if (!releaseWithDeps?.dependencies) {
        throw new Error(
          'Changelog has no release with dependencies for this test',
        );
      }

      const latestIndex = releases.indexOf(releaseWithDeps);
      const releasesFromLatest =
        latestIndex >= 0 ? releases.slice(latestIndex) : releases;
      const depName = Object.keys(releaseWithDeps.dependencies)[0]!;
      const upgradedRelease = {
        ...releaseWithDeps,
        version: TEST_VERSION_DEPENDENCY_UPGRADE,
        dependencies: {
          ...releaseWithDeps.dependencies,
          ...increasePatchVersion(depName, releaseWithDeps.dependencies),
        },
      };

      expect(
        getAvailableUpgrades({
          currentVersion: releaseWithDeps.version,
          currentDependencies: {
            [depName]: releaseWithDeps.dependencies[depName]!,
          },
          releases: [upgradedRelease, ...releasesFromLatest],
        }).availableUpgrades,
      ).toHaveLength(1);
    });

    it('finds upgrade when a devDependency has a higher patch version', async () => {
      const {releases} = await getChangelog();
      const releaseWithDevDeps = releases.find(
        (r) => r.devDependencies && Object.keys(r.devDependencies).length > 0,
      );
      if (!releaseWithDevDeps?.devDependencies) {
        throw new Error(
          'Changelog has no release with devDependencies for this test',
        );
      }

      const latestIndex = releases.indexOf(releaseWithDevDeps);
      const releasesFromLatest =
        latestIndex >= 0 ? releases.slice(latestIndex) : releases;
      const devDepName = Object.keys(releaseWithDevDeps.devDependencies)[0]!;

      const upgradedDevRelease = {
        ...releaseWithDevDeps,
        version: TEST_VERSION_DEV_DEPENDENCY_UPGRADE,
        devDependencies: {
          ...releaseWithDevDeps.devDependencies,
          ...increasePatchVersion(
            devDepName,
            releaseWithDevDeps.devDependencies,
          ),
        },
      };

      expect(
        getAvailableUpgrades({
          currentVersion: releaseWithDevDeps.version,
          currentDependencies: {
            [devDepName]: releaseWithDevDeps.devDependencies[devDepName]!,
          },
          releases: [upgradedDevRelease, ...releasesFromLatest],
        }).availableUpgrades,
      ).toHaveLength(1);
    });

    it('reports no upgrade when both dependency and devDependency match latest', async () => {
      const {releases} = await getChangelog();
      const releaseWithBoth = releases.find(
        (r) =>
          r.dependencies &&
          Object.keys(r.dependencies).length > 0 &&
          r.devDependencies &&
          Object.keys(r.devDependencies).length > 0,
      );
      if (!releaseWithBoth?.dependencies || !releaseWithBoth?.devDependencies) {
        throw new Error(
          'Changelog has no release with both dependencies and devDependencies for this test',
        );
      }

      const latestIndex = releases.indexOf(releaseWithBoth);
      const releasesFromLatest =
        latestIndex >= 0 ? releases.slice(latestIndex) : releases;
      const depName = Object.keys(releaseWithBoth.dependencies)[0]!;
      const devDepName = Object.keys(releaseWithBoth.devDependencies)[0]!;

      expect(
        getAvailableUpgrades({
          currentVersion: releaseWithBoth.version,
          currentDependencies: {
            [depName]: releaseWithBoth.dependencies[depName]!,
            [devDepName]: releaseWithBoth.devDependencies[devDepName]!,
          },
          releases: [{...releaseWithBoth}, ...releasesFromLatest],
        }).availableUpgrades,
      ).toHaveLength(0);
    });
  });

  describe('getSelectedRelease', () => {
    it('prioritizes a passed target --version over a select prompt if available', async () => {
      await inTemporaryHydrogenRepo(
        async (appPath) => {
          const {releases} = await getChangelog();
          const current = await getHydrogenVersion({appPath});

          expect(current?.currentVersion).toBeDefined();

          const {availableUpgrades} = getAvailableUpgrades({
            ...current,
            releases,
          });

          await expect(
            getSelectedRelease({
              availableUpgrades,
              currentVersion: current.currentVersion,
              currentDependencies: current.currentDependencies,
              targetVersion: '2023.7.10',
            }),
          ).resolves.toMatchObject({
            version: '2023.7.10',
          });

          expect(renderSelectPrompt).not.toHaveBeenCalled();
        },
        {
          cleanGitRepo: true,
          packageJson: OUTDATED_HYDROGEN_PACKAGE_JSON,
        },
      );
    });

    it('prompts if a passed target --version is not a valid upgradable version', async () => {
      await inTemporaryHydrogenRepo(
        async (appPath) => {
          const {releases} = await getChangelog();
          const current = await getHydrogenVersion({appPath});

          expect(current?.currentVersion).toBeDefined();

          const {availableUpgrades} = getAvailableUpgrades({
            ...current,
            releases,
          });

          // Choose latest release
          vi.mocked(renderSelectPrompt<Release>).mockImplementationOnce(
            ({choices}) => Promise.resolve(choices[0]?.value!),
          );

          await expect(
            getSelectedRelease({
              availableUpgrades,
              currentVersion: current!.currentVersion!,
              currentDependencies: current!.currentDependencies!,
              targetVersion: '2023.1.5',
            }),
          ).resolves.toMatchObject(availableUpgrades[0]!);

          expect(renderSelectPrompt).toHaveBeenCalled();
        },
        {
          cleanGitRepo: true,
          packageJson: OUTDATED_HYDROGEN_PACKAGE_JSON,
        },
      );
    });

    it('prompts to select a release if no target --version is passed', async () => {
      await inTemporaryHydrogenRepo(
        async (appPath) => {
          const {releases} = await getChangelog();
          const previousRelease = releases[1];
          const latestRelease = releases[0];
          const current = await getHydrogenVersion({appPath});

          expect(current?.currentVersion).toBeDefined();

          const {availableUpgrades} = getAvailableUpgrades({
            ...current,
            releases,
          });

          // Choose latest release
          vi.mocked(renderSelectPrompt<Release>).mockImplementationOnce(
            ({choices}) => Promise.resolve(choices[0]?.value!),
          );

          await expect(
            getSelectedRelease({
              availableUpgrades,
              currentVersion: previousRelease!.version,
              currentDependencies: {},
            }),
          ).resolves.toMatchObject(availableUpgrades[0]!);

          expect(renderSelectPrompt).toHaveBeenCalledWith({
            message: expect.stringContaining(previousRelease!.version),
            choices: expect.arrayContaining([
              {
                label: expect.stringContaining(latestRelease!.version),
                value: latestRelease,
              },
            ]),
            defaultValue: latestRelease,
          });
        },
        {
          cleanGitRepo: true,
          packageJson: OUTDATED_HYDROGEN_PACKAGE_JSON,
        },
      );
    });
  });

  describe('getCumulativeRelease', () => {
    const makeRelease = (version: string, overrides: Partial<Release> = {}) =>
      ({
        version,
        hash: 'abc',
        commit: 'https://github.com/Shopify/hydrogen/commit/abc',
        pr: 'https://github.com/Shopify/hydrogen/pull/1',
        date: '2025-01-01',
        title: '',
        dependencies: {'@shopify/hydrogen': version},
        devDependencies: {},
        features: [],
        fixes: [],
        ...overrides,
      }) as Release;

    it('returns the correct fixes and features for a release range thats outdated', async () => {
      await inTemporaryHydrogenRepo(
        async (appPath) => {
          const {releases} = await getChangelog();
          const current = await getHydrogenVersion({appPath});

          expect(current?.currentVersion).toBeDefined();

          const {availableUpgrades} = getAvailableUpgrades({
            ...current,
            releases,
          });

          // 2023.4.1
          const selectedRelease = releases.find(
            (release) => release.version === '2023.4.1',
          );

          if (!selectedRelease) {
            throw new Error(
              'Test setup: 2023.4.1 not found in changelog - is this fixture stale?',
            );
          }

          // testing from 2023.1.6 (outdated) to 2023.4.1
          const {features, fixes, removeDependencies, removeDevDependencies} =
            getCumulativeRelease({
              availableUpgrades,
              ...current,
              selectedRelease,
            });

          expect(features).toEqual(CUMULATIVE_RELEASE.features);
          expect(fixes).toEqual(CUMULATIVE_RELEASE.fixes);
          expect(removeDependencies).toEqual(
            CUMULATIVE_RELEASE.removeDependencies,
          );
          expect(removeDevDependencies).toEqual(
            CUMULATIVE_RELEASE.removeDevDependencies,
          );
        },
        {
          cleanGitRepo: true,
          packageJson: OUTDATED_HYDROGEN_PACKAGE_JSON,
        },
      );
    });

    it('accumulates real removeDependencies when upgrading across the React Router migration', async () => {
      await inTemporaryHydrogenRepo(
        async (appPath) => {
          const {releases} = await getChangelog();
          const current = await getHydrogenVersion({appPath});

          expect(current?.currentVersion).toBeDefined();

          const {availableUpgrades} = getAvailableUpgrades({
            ...current,
            releases,
          });

          // 2025.7.0 is the React Router migration release that drops @shopify/remix-oxygen and Remix packages.
          // This test ensures cumulative dependency removal works for the actual migration scenario.
          // If the migration release version ever changes, update this version string.
          const selectedRelease = releases.find(
            (release) => release.version === '2025.7.0',
          );

          if (!selectedRelease) {
            throw new Error(
              'Test setup: 2025.7.0 not found in changelog - is this fixture stale?',
            );
          }

          const {removeDependencies, removeDevDependencies} =
            getCumulativeRelease({
              availableUpgrades,
              ...current,
              selectedRelease,
            });

          // @shopify/remix-oxygen and @remix-run/* are removed without being re-added
          expect(removeDependencies).toContain('@shopify/remix-oxygen');
          expect(removeDependencies).toContain('@remix-run/react');
          expect(removeDependencies).toContain('@remix-run/server-runtime');
          expect(removeDevDependencies).toContain('@remix-run/dev');

          // react-router is re-added at a new version so it stays
          expect(removeDependencies).not.toContain('react-router');
          expect(removeDependencies).not.toContain('react-router-dom');
        },
        {
          cleanGitRepo: true,
          packageJson: PRE_MIGRATION_PACKAGE_JSON,
        },
      );
    });

    it('accumulates removeDependencies from intermediate releases', () => {
      // Simulates: user on 2025.5.0, upgrading to 2025.10.0.
      // 2025.7.0 removes @shopify/remix-oxygen (a breaking migration).
      // 2025.10.0 is the target and knows nothing about remix-oxygen.
      const target = makeRelease('2025.10.0');
      const intermediate = makeRelease('2025.7.0', {
        removeDependencies: ['@shopify/remix-oxygen', '@remix-run/react'],
        removeDevDependencies: ['@remix-run/dev'],
      });
      const from = makeRelease('2025.5.0');

      const {removeDependencies, removeDevDependencies} = getCumulativeRelease({
        availableUpgrades: [target, intermediate, from],
        selectedRelease: target,
        currentVersion: '2025.5.0',
      });

      expect(removeDependencies).toContain('@shopify/remix-oxygen');
      expect(removeDependencies).toContain('@remix-run/react');
      expect(removeDevDependencies).toContain('@remix-run/dev');
    });

    it('accumulates dependencies and devDependencies from intermediate releases (last-write-wins)', () => {
      // Simulates: user on 2025.5.1, upgrading to 2026.1.0.
      // @react-router/dev was bumped to 7.12.0 in 2025.7.1 (intermediate).
      // 2026.1.0 (target) does not repeat the react-router bump.
      // The cumulative result must include @react-router/dev@7.12.0 so that
      // upgradeNodeModules can install it and resolve the peer dep conflict.
      const target = makeRelease('2026.1.0', {
        dependencies: {'@shopify/hydrogen': '2026.1.0'},
        devDependencies: {},
      });
      const intermediate = makeRelease('2025.7.1', {
        dependencies: {
          '@shopify/hydrogen': '2025.7.1',
          'react-router': '7.12.0',
        },
        devDependencies: {'@react-router/dev': '7.12.0'},
      });
      const from = makeRelease('2025.5.1');

      const {dependencies, devDependencies} = getCumulativeRelease({
        availableUpgrades: [target, intermediate, from],
        selectedRelease: target,
        currentVersion: '2025.5.1',
      });

      // Intermediate bump flows through to the cumulative result
      expect(dependencies['react-router']).toBe('7.12.0');
      expect(devDependencies['@react-router/dev']).toBe('7.12.0');
      // Target release dep still present
      expect(dependencies['@shopify/hydrogen']).toBe('2026.1.0');
    });

    it('uses last-write-wins when a dep is bumped in multiple intermediate releases', () => {
      const target = makeRelease('2026.1.0', {
        dependencies: {'@shopify/hydrogen': '2026.1.0'},
        devDependencies: {},
      });
      const newer = makeRelease('2025.7.1', {
        devDependencies: {'@react-router/dev': '7.12.0'},
      });
      const older = makeRelease('2025.7.0', {
        devDependencies: {'@react-router/dev': '7.9.2'},
      });
      const from = makeRelease('2025.5.1');

      const {devDependencies} = getCumulativeRelease({
        availableUpgrades: [target, newer, older, from],
        selectedRelease: target,
        currentVersion: '2025.5.1',
      });

      // The newer release's version wins
      expect(devDependencies['@react-router/dev']).toBe('7.12.0');
    });

    it('excludes removeDependencies for deps that are re-added in any release', () => {
      // react-router is removed (old Remix version) AND re-added at a new version
      // in the same release — it should not appear in cumulative removeDependencies.
      const target = makeRelease('2025.10.0');
      const intermediate = makeRelease('2025.7.0', {
        dependencies: {
          '@shopify/hydrogen': '2025.7.0',
          'react-router': '7.9.2',
        },
        removeDependencies: ['@shopify/remix-oxygen', 'react-router'],
      });
      const from = makeRelease('2025.5.0');

      const {removeDependencies} = getCumulativeRelease({
        availableUpgrades: [target, intermediate, from],
        selectedRelease: target,
        currentVersion: '2025.5.0',
      });

      expect(removeDependencies).toContain('@shopify/remix-oxygen');
      expect(removeDependencies).not.toContain('react-router');
    });

    it('excludes removeDependencies when removed and re-added in the same release (>= operator behavior)', () => {
      // This test specifically validates the >= operator in upgrade.ts:652 and upgrade.ts:659.
      // When a package appears in both removeDependencies AND dependencies of the SAME release,
      // it should be excluded from cumulative removals (treated as a version upgrade, not removal).
      // This is the React Router 7 migration scenario: old react-router removed, new react-router added.
      const singleRelease = makeRelease('2025.7.0', {
        dependencies: {
          '@shopify/hydrogen': '2025.7.0',
          'react-router': '7.9.2', // Re-added in same release
        },
        removeDependencies: ['react-router'], // Also removed in same release
      });
      const from = makeRelease('2025.5.0');

      const {removeDependencies} = getCumulativeRelease({
        availableUpgrades: [singleRelease, from],
        selectedRelease: singleRelease,
        currentVersion: '2025.5.0',
      });

      // react-router is removed and re-added in the SAME release (i >= removalI)
      // so it should NOT appear in cumulative removeDependencies
      expect(removeDependencies).not.toContain('react-router');
    });

    it('deduplicates removeDependencies listed in multiple releases', () => {
      const target = makeRelease('2025.10.0', {
        removeDependencies: ['@shopify/remix-oxygen'],
      });
      const intermediate = makeRelease('2025.7.0', {
        removeDependencies: ['@shopify/remix-oxygen'],
      });
      const from = makeRelease('2025.5.0');

      const {removeDependencies} = getCumulativeRelease({
        availableUpgrades: [target, intermediate, from],
        selectedRelease: target,
        currentVersion: '2025.5.0',
      });

      expect(
        removeDependencies.filter((d) => d === '@shopify/remix-oxygen'),
      ).toHaveLength(1);
    });

    it('includes removals when an intermediate release has a dep and a later intermediate release removes it', () => {
      // Scenario: upgrading from 2025.5.0 → 2025.10.0
      // remix exists in an intermediate release (2025.6.0), is removed in 2025.7.0,
      // and is never re-added. It should be included in cumulative removals.
      const intermediateWithRemix = makeRelease('2025.6.0', {
        dependencies: {
          '@shopify/hydrogen': '2025.6.0',
          remix: '4.0.0',
        },
      });
      const releaseRemovingRemix = makeRelease('2025.7.0', {
        removeDependencies: ['remix'],
      });
      const targetRelease = makeRelease('2025.10.0');

      const {removeDependencies} = getCumulativeRelease({
        availableUpgrades: [
          targetRelease,
          releaseRemovingRemix,
          intermediateWithRemix,
        ],
        selectedRelease: targetRelease,
        currentVersion: '2025.5.0',
      });

      expect(removeDependencies).toContain('remix');
    });

    it('handles releases that omit dependencies maps', () => {
      const targetRelease = makeRelease('2025.10.0');
      const releaseWithoutDependencyMaps = {
        ...makeRelease('2025.7.0', {
          removeDependencies: ['@shopify/remix-oxygen'],
        }),
        dependencies: undefined,
        devDependencies: undefined,
      } as unknown as Release;
      const fromRelease = makeRelease('2025.5.0');

      const {removeDependencies} = getCumulativeRelease({
        availableUpgrades: [
          targetRelease,
          releaseWithoutDependencyMaps,
          fromRelease,
        ],
        selectedRelease: targetRelease,
        currentVersion: '2025.5.0',
      });

      expect(removeDependencies).toContain('@shopify/remix-oxygen');
    });

    it('includes removal when package moves from devDependencies to dependencies', () => {
      // Scenario: typescript is removed from devDependencies, then re-added as a regular dependency
      // The removal from devDependencies should still appear in removeDevDependencies
      const targetRelease = makeRelease('2025.10.0', {
        dependencies: {
          '@shopify/hydrogen': '2025.10.0',
          typescript: '5.0.0',
        },
      });
      const intermediateRelease = makeRelease('2025.7.0', {
        removeDevDependencies: ['typescript'],
      });
      const fromRelease = makeRelease('2025.5.0');

      const {removeDependencies, removeDevDependencies} = getCumulativeRelease({
        availableUpgrades: [targetRelease, intermediateRelease, fromRelease],
        selectedRelease: targetRelease,
        currentVersion: '2025.5.0',
      });

      // typescript should be removed from devDependencies (not suppressed by cross-type re-addition)
      expect(removeDevDependencies).toContain('typescript');
      expect(removeDependencies).not.toContain('typescript');
    });

    it('includes removal when package moves from dependencies to devDependencies', () => {
      // Scenario: lodash is removed from dependencies, then re-added as a devDependency
      // The removal from dependencies should still appear in removeDependencies
      const targetRelease = makeRelease('2025.10.0', {
        devDependencies: {
          lodash: '4.17.21',
        },
      });
      const intermediateRelease = makeRelease('2025.7.0', {
        removeDependencies: ['lodash'],
      });
      const fromRelease = makeRelease('2025.5.0');

      const {removeDependencies, removeDevDependencies} = getCumulativeRelease({
        availableUpgrades: [targetRelease, intermediateRelease, fromRelease],
        selectedRelease: targetRelease,
        currentVersion: '2025.5.0',
      });

      // lodash should be removed from dependencies (not suppressed by cross-type re-addition)
      expect(removeDependencies).toContain('lodash');
      expect(removeDevDependencies).not.toContain('lodash');
    });

    it('integration: upgradeNodeModules accepts cumulative removals from getCumulativeRelease', async () => {
      const testRelease = makeRelease('2025.10.0', {
        dependencies: {'@shopify/hydrogen': '2025.10.0'},
        devDependencies: {},
      });
      const intermediateRelease = makeRelease('2025.7.0', {
        removeDependencies: ['@shopify/remix-oxygen', '@remix-run/react'],
        removeDevDependencies: ['@remix-run/dev'],
      });
      const fromRelease = makeRelease('2025.5.0');

      const cumulativeRelease = getCumulativeRelease({
        availableUpgrades: [testRelease, intermediateRelease, fromRelease],
        selectedRelease: testRelease,
        currentVersion: '2025.5.0',
      });

      expect(cumulativeRelease.removeDependencies).toContain(
        '@shopify/remix-oxygen',
      );
      expect(cumulativeRelease.removeDependencies).toContain(
        '@remix-run/react',
      );
      expect(cumulativeRelease.removeDevDependencies).toContain(
        '@remix-run/dev',
      );

      await inTemporaryHydrogenRepo(
        async (appPath) => {
          const currentDependencies = {
            '@shopify/hydrogen': '2025.5.0',
            '@shopify/remix-oxygen': '2.0.0',
            '@remix-run/react': '2.0.0',
            '@remix-run/dev': '2.0.0',
          };

          await upgradeNodeModules({
            appPath,
            selectedRelease: testRelease,
            currentDependencies,
            cumulativeRemoveDependencies: cumulativeRelease.removeDependencies,
            cumulativeRemoveDevDependencies:
              cumulativeRelease.removeDevDependencies,
          });

          expect(renderTasks).toHaveBeenCalledWith(
            expect.arrayContaining([
              expect.objectContaining({
                title: 'Removing deprecated dependencies',
              }),
              expect.objectContaining({
                title: 'Upgrading dependencies',
              }),
            ]),
            expect.anything(),
          );
        },
        {
          cleanGitRepo: true,
          packageJson: {
            dependencies: {
              '@shopify/hydrogen': '2025.5.0',
            },
          },
        },
      );
    });
  });

  describe('displayConfirmation', () => {
    it('renders a confirmation prompt to continue or return to the previous menu', async () => {
      await inTemporaryHydrogenRepo(
        async () => {
          const {releases} = await getChangelog();

          // 2023.10.0
          const selectedRelease = releases.find(
            (release) => release.version === '2023.10.0',
          ) as (typeof releases)[0];

          await expect(
            displayConfirmation({
              cumulativeRelease: CUMULATIVE_RELEASE,
              selectedRelease,
            }),
          ).resolves.toEqual(false);

          const info = outputMock.info();
          expect(info).toMatch('Included in this upgrade');

          [...CUMULATIVE_RELEASE.features, ...CUMULATIVE_RELEASE.fixes].forEach(
            (feat) =>
              // Cut the string to avoid matching the banner
              expect(info).toMatch(feat.title.slice(0, 15)),
          );

          // With empty removeDependencies, the "Removed packages" section should NOT appear
          expect(info).not.toMatch('Removed packages');

          expect(renderConfirmationPrompt).toHaveBeenCalledWith({
            message: `Are you sure you want to upgrade to ${selectedRelease.version}?`,
            cancellationMessage: `No, choose another version`,
            defaultValue: true,
          });
        },
        {
          cleanGitRepo: true,
          packageJson: OUTDATED_HYDROGEN_PACKAGE_JSON,
        },
      );
    });
    it('displays removed packages when cumulativeRelease has removals', async () => {
      await inTemporaryHydrogenRepo(
        async () => {
          const {releases} = await getChangelog();

          const selectedRelease = releases.find(
            (release) => release.version === '2023.10.0',
          ) as (typeof releases)[0];

          const releaseWithRemovals = {
            ...CUMULATIVE_RELEASE,
            removeDependencies: ['@remix-run/react'],
            removeDevDependencies: ['@remix-run/dev'],
          };

          await expect(
            displayConfirmation({
              cumulativeRelease: releaseWithRemovals,
              selectedRelease,
            }),
          ).resolves.toEqual(false);

          const info = outputMock.info();
          expect(info).toMatch('Removed packages');
          expect(info).toMatch('@remix-run/react');
          expect(info).toMatch('@remix-run/dev');
        },
        {
          cleanGitRepo: true,
          packageJson: OUTDATED_HYDROGEN_PACKAGE_JSON,
        },
      );
    });

    it('displays removed packages when release has only removals and no features or fixes', async () => {
      await inTemporaryHydrogenRepo(
        async () => {
          const {releases} = await getChangelog();

          const selectedRelease = releases.find(
            (release) => release.version === '2023.10.0',
          ) as (typeof releases)[0];

          const removalsOnlyRelease: CumulativeRelease = {
            features: [],
            fixes: [],
            removeDependencies: ['@remix-run/react'],
            removeDevDependencies: [],
            dependencies: {},
            devDependencies: {},
          };

          await expect(
            displayConfirmation({
              cumulativeRelease: removalsOnlyRelease,
              selectedRelease,
            }),
          ).resolves.toEqual(false);

          expect(renderInfo).toHaveBeenCalledWith(
            expect.objectContaining({
              headline: 'Included in this upgrade:',
              customSections: expect.arrayContaining([
                expect.objectContaining({title: 'Removed packages'}),
              ]),
            }),
          );
        },
        {
          cleanGitRepo: true,
          packageJson: OUTDATED_HYDROGEN_PACKAGE_JSON,
        },
      );
    });
  });

  describe('generateUpgradeInstructionsFile', () => {
    it('includes backtick-wrapped removed packages in markdown output', async () => {
      await inTemporaryHydrogenRepo(
        async (appPath) => {
          const {releases} = await getChangelog();

          const selectedRelease = releases.find(
            (release) => release.version === '2023.10.0',
          ) as (typeof releases)[0];

          const releaseWithRemovals: CumulativeRelease = {
            ...CUMULATIVE_RELEASE,
            removeDependencies: ['@remix-run/react'],
            removeDevDependencies: ['@remix-run/dev'],
          };

          const resultPath = await generateUpgradeInstructionsFile({
            appPath,
            cumulativeRelease: releaseWithRemovals,
            currentVersion: '2023.1.6',
            selectedRelease,
          });

          expect(resultPath).toBeDefined();

          const mdContent = await readFile(
            joinPath(appPath, resultPath!),
            'utf8',
          );

          expect(mdContent).toContain('## Removed packages');
          expect(mdContent).toContain('- `@remix-run/react`');
          expect(mdContent).toContain('- `@remix-run/dev`');
        },
        {
          cleanGitRepo: true,
          packageJson: OUTDATED_HYDROGEN_PACKAGE_JSON,
        },
      );
    });

    it('omits Removed packages section when cumulativeRelease has no removals', async () => {
      await inTemporaryHydrogenRepo(
        async (appPath) => {
          const {releases} = await getChangelog();

          const selectedRelease = releases.find(
            (release) => release.version === '2023.10.0',
          ) as (typeof releases)[0];

          // CUMULATIVE_RELEASE has features/fixes (so a file is generated)
          // but empty removeDependencies and removeDevDependencies
          const resultPath = await generateUpgradeInstructionsFile({
            appPath,
            cumulativeRelease: CUMULATIVE_RELEASE,
            currentVersion: '2023.1.6',
            selectedRelease,
          });

          expect(resultPath).toBeDefined();

          const mdContent = await readFile(
            joinPath(appPath, resultPath!),
            'utf8',
          );

          expect(mdContent).not.toContain('## Removed packages');
        },
        {
          cleanGitRepo: true,
          packageJson: OUTDATED_HYDROGEN_PACKAGE_JSON,
        },
      );
    });

    it('generates instructions file when release has only removals and no features or fixes', async () => {
      await inTemporaryHydrogenRepo(
        async (appPath) => {
          const {releases} = await getChangelog();

          const selectedRelease = releases.find(
            (release) => release.version === '2023.10.0',
          ) as (typeof releases)[0];

          const removalsOnlyRelease: CumulativeRelease = {
            features: [],
            fixes: [],
            removeDependencies: ['@remix-run/react'],
            removeDevDependencies: [],
            dependencies: {},
            devDependencies: {},
          };

          const resultPath = await generateUpgradeInstructionsFile({
            appPath,
            cumulativeRelease: removalsOnlyRelease,
            currentVersion: '2023.1.6',
            selectedRelease,
          });

          expect(resultPath).toBeDefined();

          const mdContent = await readFile(
            joinPath(appPath, resultPath!),
            'utf8',
          );

          expect(mdContent).toContain('## Removed packages');
          expect(mdContent).toContain('- `@remix-run/react`');
          expect(mdContent).not.toContain('----\n\n----');
        },
        {
          cleanGitRepo: true,
          packageJson: OUTDATED_HYDROGEN_PACKAGE_JSON,
        },
      );
    });

    it('overwrites an existing instructions file without prompting when force is enabled', async () => {
      await inTemporaryHydrogenRepo(
        async (appPath) => {
          const {releases} = await getChangelog();

          const selectedRelease = releases.find(
            (release) => release.version === '2023.10.0',
          ) as (typeof releases)[0];

          const resultPath = await generateUpgradeInstructionsFile({
            appPath,
            cumulativeRelease: CUMULATIVE_RELEASE,
            currentVersion: '2023.1.6',
            selectedRelease,
          });

          expect(resultPath).toBeDefined();

          const filePath = joinPath(appPath, resultPath!);
          await writeFile(filePath, 'old instructions');
          vi.mocked(renderConfirmationPrompt).mockClear();

          await expect(
            generateUpgradeInstructionsFile({
              appPath,
              cumulativeRelease: CUMULATIVE_RELEASE,
              currentVersion: '2023.1.6',
              selectedRelease,
              force: true,
            }),
          ).resolves.toEqual(resultPath);

          expect(renderConfirmationPrompt).not.toHaveBeenCalled();
          await expect(readFile(filePath, 'utf8')).resolves.not.toEqual(
            'old instructions',
          );
        },
        {
          cleanGitRepo: true,
          packageJson: OUTDATED_HYDROGEN_PACKAGE_JSON,
        },
      );
    });
  });

  describe('displayDevUpgradeNotice', () => {
    it('shows a monorepo notice when Hydrogen uses workspace protocol', async () => {
      await inTemporaryHydrogenRepo(
        async (targetPath) => {
          await expect(
            displayDevUpgradeNotice({targetPath}),
          ).resolves.not.toThrow();

          expect(renderInfo).toHaveBeenCalledWith(
            expect.objectContaining({
              headline: 'Using monorepo @shopify/hydrogen dependency',
            }),
          );
          expect(outputMock.warn()).toBe('');
        },
        {
          cleanGitRepo: false,
          packageJson: {
            ...OUTDATED_HYDROGEN_PACKAGE_JSON,
            dependencies: {
              ...OUTDATED_HYDROGEN_PACKAGE_JSON.dependencies,
              '@shopify/hydrogen': 'workspace:*',
            },
          },
        },
      );
    });

    it('shows up a notice if Hydrogen is outdated', async () => {
      await inTemporaryHydrogenRepo(
        async (targetPath) => {
          await expect(
            displayDevUpgradeNotice({targetPath}),
          ).resolves.not.toThrow();

          expect(outputMock.info()).toMatch(
            /new @shopify\/hydrogen versions? available/i,
          );
          expect(outputMock.info()).toMatch(
            /Current: [\d.] | Latest: [\d.]+\s{2,}/i,
          );
          expect(outputMock.info()).toMatch(
            /The next \d+ version\(s\) include/i,
          );
          expect(outputMock.info()).toMatch('Run `h2 upgrade`');
        },
        {cleanGitRepo: false, packageJson: OUTDATED_HYDROGEN_PACKAGE_JSON},
      );
    });

    it.skip('shows up a notice if there are related dependencies to upgrade', async () => {
      const latestHydrogenVersion = (await (
        await getChangelog()
      ).releases[0]?.version) as string;

      await inTemporaryHydrogenRepo(
        async (targetPath) => {
          await expect(
            displayDevUpgradeNotice({targetPath}),
          ).resolves.not.toThrow();

          expect(outputMock.info()).toMatch(
            /new @shopify\/hydrogen versions? available/i,
          );
          expect(outputMock.info()).toMatch(
            /Current: [\d.] | Latest: [\d.]+ with updated dependencies\s{1,}/i,
          );
          expect(outputMock.info()).toMatch(/The next 1 version\(s\) include/i);
          expect(outputMock.info()).toMatch(
            `or \`h2 upgrade --version ${latestHydrogenVersion}\``,
          );
        },
        {
          cleanGitRepo: false,
          packageJson: {
            ...OUTDATED_HYDROGEN_PACKAGE_JSON,
            dependencies: {
              ...OUTDATED_HYDROGEN_PACKAGE_JSON.dependencies,
              '@shopify/hydrogen': latestHydrogenVersion,
            },
          },
        },
      );
    });

    it('getAvailableUpgrades correctly identifies upgrades when current version is not in changelog', async () => {
      const mockChangelog = {
        url: 'https://test.com',
        version: '1',
        releases: [
          {
            title: 'Latest version',
            version: '2025.7.0',
            hash: 'abc123',
            commit: 'https://github.com/test',
            pr: 'https://github.com/test',
            dependencies: {'@shopify/hydrogen': '2025.7.0'},
            devDependencies: {},
            dependenciesMeta: {},
            fixes: [],
            features: [],
            date: '2025-07-01',
          },
          {
            title: 'Older version',
            version: '2025.4.1',
            hash: 'def456',
            commit: 'https://github.com/test',
            pr: 'https://github.com/test',
            dependencies: {'@shopify/hydrogen': '2025.4.1'},
            devDependencies: {},
            dependenciesMeta: {},
            fixes: [],
            features: [],
            date: '2025-04-01',
          },
        ] as Release[],
      };

      const currentVersion = '2025.5.0';
      const currentDependencies = {'@shopify/hydrogen': '2025.5.0'};

      const {availableUpgrades} = getAvailableUpgrades({
        releases: mockChangelog.releases,
        currentVersion,
        currentDependencies,
      });

      expect(availableUpgrades).toHaveLength(1);
      expect(availableUpgrades[0]?.version).toBe('2025.7.0');
    });

    it.skip('displayDevUpgradeNotice shows correct versions when current version is not in changelog', async () => {
      const mockPackageJson = {
        dependencies: {
          '@shopify/hydrogen': '2025.5.0',
        },
        devDependencies: {},
      };

      await inTemporaryHydrogenRepo(
        async (targetPath) => {
          await expect(
            displayDevUpgradeNotice({targetPath}),
          ).resolves.not.toThrow();

          const output = outputMock.info();

          expect(output).toMatch(/Current: 2025\.5\.0.*Latest: 2025\.7\.1/);

          expect(output).toMatch(/2025\.7\.0/);

          expect(output).not.toMatch(/2023\.1\.1/);
          expect(output).not.toMatch(/2023\.1\.2/);
          expect(output).not.toMatch(/2023\.1\.3/);
          expect(output).not.toMatch(/2023\.1\.4/);
          expect(output).not.toMatch(/2023\.1\.5/);
        },
        {
          cleanGitRepo: false,
          packageJson: mockPackageJson,
        },
      );
    });

    it.skip('displayDevUpgradeNotice shows versions in correct order (newest first, next version last)', async () => {
      const mockPackageJson = {
        dependencies: {
          '@shopify/hydrogen': '2025.1.0',
        },
        devDependencies: {},
      };

      await inTemporaryHydrogenRepo(
        async (targetPath) => {
          await expect(
            displayDevUpgradeNotice({targetPath}),
          ).resolves.not.toThrow();

          const output = outputMock.info();

          const versionLineMatches =
            output.match(/•\s+(\d{4}\.\d+\.\d+)\s+-\s+/g) || [];

          expect(versionLineMatches.length).toBeGreaterThan(1);

          const firstVersionLine = versionLineMatches[0];
          const lastVersionLine =
            versionLineMatches[versionLineMatches.length - 1];

          expect(firstVersionLine).toContain('2025.7.1');
          expect(lastVersionLine).toMatch(/2025\.4\.[1-2]/);
        },
        {
          cleanGitRepo: false,
          packageJson: mockPackageJson,
        },
      );
    });
  });

  describe('upgradeNodeModules', () => {
    it('runs the upgrade command task', async () => {
      await inTemporaryHydrogenRepo(
        async (appPath) => {
          const {releases} = await getChangelog();

          const selectedRelease = releases.find(
            (release) => release.version === '2023.10.0',
          ) as (typeof releases)[0];

          const currentDependencies = {
            ...OUTDATED_HYDROGEN_PACKAGE_JSON.dependencies,
            ...OUTDATED_HYDROGEN_PACKAGE_JSON.devDependencies,
          };

          await upgradeNodeModules({
            appPath,
            selectedRelease,
            currentDependencies,
            cumulativeRemoveDependencies: [],
            cumulativeRemoveDevDependencies: [],
          });

          // With empty removal lists, only the upgrade task should be present
          expect(renderTasks).toHaveBeenCalledWith(
            expect.arrayContaining([
              expect.objectContaining({
                title: 'Upgrading dependencies',
              }),
            ]),
            expect.anything(),
          );

          // The removal task should NOT be present when no deps to remove
          expect(renderTasks).toHaveBeenCalledWith(
            expect.not.arrayContaining([
              expect.objectContaining({
                title: 'Removing deprecated dependencies',
              }),
            ]),
            expect.anything(),
          );
        },
        {
          cleanGitRepo: true,
          packageJson: OUTDATED_HYDROGEN_PACKAGE_JSON,
        },
      );
    });

    it('builds the upgrade command args', async () => {
      const {releases} = await getChangelog();

      const selectedRelease = releases.find(
        (release) => release.version === '2023.10.0',
      ) as (typeof releases)[0];

      const currentDependencies = {
        ...OUTDATED_HYDROGEN_PACKAGE_JSON.dependencies,
        ...OUTDATED_HYDROGEN_PACKAGE_JSON.devDependencies,
      };

      const result: string[] = [
        '@shopify/hydrogen@2023.10.0',
        '@shopify/cli-hydrogen@6.0.0',
        '@shopify/remix-oxygen@2.0.0',
        '@remix-run/react@2.1.0',
        '@remix-run/dev@2.1.0',
        'typescript@5.2.2',
      ];

      const args = buildUpgradeCommandArgs({
        selectedRelease,
        currentDependencies,
      });

      expect(args).toEqual(expect.arrayContaining(result));
    });

    it('upgrades and syncs up all available React Router deps if they are out-of-date', async () => {
      const selectedRelease = REACT_ROUTER_RELEASE;

      const currentDependencies = {
        ...OUTDATED_HYDROGEN_PACKAGE_JSON_WITH_REACT_ROUTER.dependencies,
        'react-router': '7.0.0',
        ...OUTDATED_HYDROGEN_PACKAGE_JSON_WITH_REACT_ROUTER.devDependencies,
        '@react-router/dev': '7.0.0',
      };

      const result: string[] = [
        '@shopify/hydrogen@2025.5.0',
        '@shopify/remix-oxygen@2.0.12',
        '@shopify/cli@3.77.1',
        '@shopify/mini-oxygen@3.2.0',
        '@shopify/hydrogen-codegen@0.3.3',
        '@shopify/oxygen-workers-types@4.1.6',
        'vite@6.2.4',
        'react-router@7.5.0',
        'react-router-dom@7.5.0',
        '@react-router/dev@7.5.0',
        '@react-router/fs-routes@7.5.0',
      ];

      const args = buildUpgradeCommandArgs({
        selectedRelease,
        currentDependencies,
      });

      expect(args).toEqual(result);
    });

    it('upgrades all available React Router deps if they are out-of-date', async () => {
      const selectedRelease = REACT_ROUTER_RELEASE;

      const currentDependencies = {
        ...OUTDATED_HYDROGEN_PACKAGE_JSON_WITH_REACT_ROUTER.dependencies,
        'react-router': '7.3.0',
        'react-router-dom': '7.3.0',
        ...OUTDATED_HYDROGEN_PACKAGE_JSON_WITH_REACT_ROUTER.devDependencies,
        '@react-router/dev': '7.3.0',
      };

      const result: string[] = [
        '@shopify/hydrogen@2025.5.0',
        '@shopify/remix-oxygen@2.0.12',
        '@shopify/cli@3.77.1',
        '@shopify/mini-oxygen@3.2.0',
        '@shopify/hydrogen-codegen@0.3.3',
        '@shopify/oxygen-workers-types@4.1.6',
        'vite@6.2.4',
        'react-router@7.5.0',
        'react-router-dom@7.5.0',
        '@react-router/dev@7.5.0',
        '@react-router/fs-routes@7.5.0',
      ];

      const args = buildUpgradeCommandArgs({
        selectedRelease,
        currentDependencies,
      });

      expect(args).toEqual(result);
    });

    it('does not upgrade React Router deps if they are more up-to-date', async () => {
      const selectedRelease = REACT_ROUTER_RELEASE;
      const currentDependencies = {
        ...OUTDATED_HYDROGEN_PACKAGE_JSON_WITH_REACT_ROUTER.dependencies,
        'react-router': '7.6.0',
        ...OUTDATED_HYDROGEN_PACKAGE_JSON_WITH_REACT_ROUTER.devDependencies,
        'react-router-dom': '7.6.0',
      };

      const result: string[] = [
        '@shopify/hydrogen@2025.5.0',
        '@shopify/remix-oxygen@2.0.12',
        '@shopify/cli@3.77.1',
        '@shopify/mini-oxygen@3.2.0',
        '@shopify/hydrogen-codegen@0.3.3',
        '@shopify/oxygen-workers-types@4.1.6',
        'vite@6.2.4',
      ];

      const args = buildUpgradeCommandArgs({
        selectedRelease,
        currentDependencies,
      });

      expect(args).toEqual(result);
    });

    it('installs all React Router packages even if only a subset exists', async () => {
      const selectedRelease = REACT_ROUTER_RELEASE;

      // Project has only react-router but missing other packages
      const currentDependencies = {
        ...OUTDATED_HYDROGEN_PACKAGE_JSON.dependencies,
        'react-router': '7.0.0',
        // Missing: react-router-dom, @react-router/dev, @react-router/fs-routes
        ...OUTDATED_HYDROGEN_PACKAGE_JSON.devDependencies,
      };

      const result: string[] = [
        '@shopify/hydrogen@2025.5.0',
        '@shopify/remix-oxygen@2.0.12',
        '@shopify/cli@3.77.1',
        '@shopify/mini-oxygen@3.2.0',
        '@shopify/hydrogen-codegen@0.3.3',
        '@shopify/oxygen-workers-types@4.1.6',
        'vite@6.2.4',
        'react-router@7.5.0',
        'react-router-dom@7.5.0',
        '@react-router/dev@7.5.0',
        '@react-router/fs-routes@7.5.0',
      ];

      const args = buildUpgradeCommandArgs({
        selectedRelease,
        currentDependencies,
      });

      // Should install ALL React Router packages, not just upgrade the existing one
      expect(args).toEqual(result);
    });

    it('does not install an optional dependency that was not installed', async () => {
      const {releases} = await getChangelog();

      const selectedRelease = Object.create(
        // @ts-expect-error - we know this release version exists
        releases.find((release) => release.version === '2023.10.0'),
      ) as (typeof releases)[0];

      // simulate a missing optional dependency
      selectedRelease.dependenciesMeta = {
        typescript: {
          required: false,
        },
      };

      const currentDependencies = {
        ...OUTDATED_HYDROGEN_PACKAGE_JSON.dependencies,
        '@remix-run/react': '2.1.0',
        ...OUTDATED_HYDROGEN_PACKAGE_JSON.devDependencies,
        '@remix-run/dev': '2.1.0',
        // simulate a missing required dependency
        typescript: '',
      };

      const result: string[] = [
        '@shopify/cli-hydrogen@6.0.0',
        '@shopify/hydrogen@2023.10.0',
        '@shopify/remix-oxygen@2.0.0',
      ];

      const args = buildUpgradeCommandArgs({
        selectedRelease,
        currentDependencies,
      });

      expect(args).toEqual(result);
    });

    it('adds a required dependency that was not installed', async () => {
      const {releases} = await getChangelog();

      // has typescript as a required dependency
      const selectedRelease = releases.find(
        (release) => release.version === '2023.10.0',
      ) as (typeof releases)[0];

      const currentDependencies = {
        ...OUTDATED_HYDROGEN_PACKAGE_JSON.dependencies,
        '@remix-run/react': '2.1.0',
        ...OUTDATED_HYDROGEN_PACKAGE_JSON.devDependencies,
        '@remix-run/dev': '2.1.0',
        // simulate a missing required dependency
        typescript: '',
      };

      const result: string[] = [
        '@shopify/cli-hydrogen@6.0.0',
        '@shopify/hydrogen@2023.10.0',
        '@shopify/remix-oxygen@2.0.0',
        `typescript@${getAbsoluteVersion(
          // @ts-expect-error - we know this release version exists
          selectedRelease.devDependencies.typescript,
        )}`,
      ];

      const args = buildUpgradeCommandArgs({
        selectedRelease,
        currentDependencies,
      });

      expect(args).toEqual(expect.arrayContaining(result));
    });

    it('does not upgrade a required dependency that is further up-to-date', async () => {
      const {releases} = await getChangelog();

      const selectedRelease = releases.find(
        (release) => release.version === '2023.10.0',
      ) as (typeof releases)[0];

      const currentDependencies = {
        ...OUTDATED_HYDROGEN_PACKAGE_JSON.dependencies,
        '@remix-run/react': '2.1.0',
        ...OUTDATED_HYDROGEN_PACKAGE_JSON.devDependencies,
        '@remix-run/dev': '2.1.0',
        typescript: '5.3.0', // more up-to-date than that of 2023.10.0
      };

      const result: string[] = [
        '@shopify/cli-hydrogen@6.0.0',
        '@shopify/hydrogen@2023.10.0',
        '@shopify/remix-oxygen@2.0.0',
      ];

      const args = buildUpgradeCommandArgs({
        selectedRelease,
        currentDependencies,
      });

      expect(args).toEqual(expect.arrayContaining(result));
    });

    it('includes deps from cumulativeDependencies that are absent from selectedRelease', () => {
      // Reproduces the 2025.5.1 → 2026.1.0 scenario: @react-router/dev was bumped in
      // an intermediate release (2025.7.1) but is absent from the target (2026.1.0).
      // Without cumulative deps, the upgrade command would never install @react-router/dev,
      // leaving a stale version that causes npm ERESOLVE.
      const selectedRelease = {
        version: '2026.1.0',
        dependencies: {'@shopify/hydrogen': '2026.1.0'},
        devDependencies: {},
        dependenciesMeta: {},
      } as unknown as Release;

      const currentDependencies = {
        '@shopify/hydrogen': '2025.5.1',
        'react-router': '7.6.0',
        '@react-router/dev': '7.6.0',
      };

      const args = buildUpgradeCommandArgs({
        selectedRelease,
        currentDependencies,
        cumulativeDependencies: {'react-router': '7.12.0'},
        cumulativeDevDependencies: {'@react-router/dev': '7.12.0'},
      });

      expect(args).toContain('@shopify/hydrogen@2026.1.0');
      // Cumulative React Router deps are included and trigger appendReactRouterDependencies
      expect(args).toContain('react-router@7.12.0');
      expect(args).toContain('@react-router/dev@7.12.0');
    });

    it('does not upgrade @next dependencies', async () => {
      const {releases} = await getChangelog();

      const selectedRelease = releases.find(
        (release) => release.version === '2023.10.0',
      ) as (typeof releases)[0];

      const currentDependencies = {
        ...OUTDATED_HYDROGEN_PACKAGE_JSON.dependencies,
        '@remix-run/react': '2.1.0',
        ...OUTDATED_HYDROGEN_PACKAGE_JSON.devDependencies,
        '@remix-run/dev': '2.1.0',
        '@shopify/hydrogen': 'next',
      };

      const result: string[] = [
        '@shopify/cli-hydrogen@6.0.0',
        '@shopify/remix-oxygen@2.0.0',
        `typescript@${getAbsoluteVersion(
          // @ts-expect-error - we know this release version exists
          selectedRelease.devDependencies.typescript,
        )}`,
      ];

      const args = buildUpgradeCommandArgs({
        selectedRelease,
        currentDependencies,
      });

      expect(args).toEqual(result);
    });
  });
});

// cumulative result when upgrading from 2023.1.6 (outdated) to 2023.4.1
const CUMULATIVE_RELEASE = {
  fixes: [
    {
      title: 'Add a default Powered-By: Shopify-Hydrogen header',
      pr: 'https://github.com/Shopify/hydrogen/pull/872',
      id: '872',
      steps: [
        {
          title:
            ' It can be disabled by passing poweredByHeader: false in the configuration object of createRequestHandler',
          code: 'YGBgdHMKaW1wb3J0IHtjcmVhdGVSZXF1ZXN0SGFuZGxlcn0gZnJvbSAnQHNob3BpZnkvcmVtaXgtb3h5Z2VuJzsKCmV4cG9ydCBkZWZhdWx0IHsKICBhc3luYyBmZXRjaChyZXF1ZXN0KSB7CiAgICAvLyAuLi4KICAgIGNvbnN0IGhhbmRsZVJlcXVlc3QgPSBjcmVhdGVSZXF1ZXN0SGFuZGxlcih7CiAgICAgIC8vIC4uLiBvdGhlciBwcm9wZXJ0aWVzIGluY2x1ZGVkCiAgICAgIHBvd2VyZWRCeUhlYWRlcjogZmFsc2UsCiAgICB9KTsKICAgIC8vIC4uLgogIH0sCn07CmBgYA',
          file: 'server.ts',
        },
      ],
    },
    {
      title: 'Updated CLI prompts',
      pr: 'https://github.com/Shopify/hydrogen/pull/733',
      id: '733',
      steps: [
        {
          title: 'Update package.json',
          code: 'YGBgZGlmZgoiZGVwZW5kZW5jaWVzIjogewotICAiQHNob3BpZnkvY2xpIjogIjMueC54IiwKKyAgIkBzaG9waWZ5L2NsaSI6ICIzLjQ1LjAiLAp9CmBgYA==',
          file: 'package.json',
        },
      ],
    },
    {
      title:
        'Added support for the Remix future flags v2_meta, v2_errorBoundary and v2_routeConvention to the generate command',
      pr: 'https://github.com/Shopify/hydrogen/pull/756',
      id: '756',
    },
    {
      title: 'Update virtual route to use Remix V2 route name conventions',
      pr: 'https://github.com/Shopify/hydrogen/pull/792',
      id: '792',
    },
    {
      title: 'Update internal Remix dependencies to 1.15.0',
      pr: 'https://github.com/Shopify/hydrogen/pull/728',
      id: '728',
      docs: 'https://github.com/remix-run/remix/releases/tag/remix%401.15.0',
    },
    {
      title: 'Improve type safety in SEO data generators',
      pr: 'https://github.com/Shopify/hydrogen/pull/763',
      id: '763',
    },
    {
      title: 'Stop hydrating with requestIdleCallback',
      pr: 'https://github.com/Shopify/hydrogen/pull/667',
      id: '667',
    },
    {
      title: 'Fix active cart session event in Live View',
      pr: 'https://github.com/Shopify/hydrogen/pull/614',
      id: '614',
      steps: [
        {
          title:
            'Introducing getStorefrontHeaders that collects the required Shopify headers for making a Storefront API call.',
          code: 'YGBgdHMKKyBpbXBvcnQge2dldFN0b3JlZnJvbnRIZWFkZXJzfSBmcm9tICdAc2hvcGlmeS9yZW1peC1veHlnZW4nOwppbXBvcnQge2NyZWF0ZVN0b3JlZnJvbnRDbGllbnQsIHN0b3JlZnJvbnRSZWRpcmVjdH0gZnJvbSAnQHNob3BpZnkvaHlkcm9nZW4nOwoKZXhwb3J0IGRlZmF1bHQgewogIGFzeW5jIGZldGNoKAogICAgcmVxdWVzdDogUmVxdWVzdCwKICAgIGVudjogRW52LAogICAgZXhlY3V0aW9uQ29udGV4dDogRXhlY3V0aW9uQ29udGV4dCwKICApOiBQcm9taXNlPFJlc3BvbnNlPiB7CgogICAgY29uc3Qge3N0b3JlZnJvbnR9ID0gY3JlYXRlU3RvcmVmcm9udENsaWVudCh7CiAgICAgIGNhY2hlLAogICAgICB3YWl0VW50aWwsCi0gICAgIGJ1eWVySXA6IGdldEJ1eWVySXAocmVxdWVzdCksCiAgICAgIGkxOG46IHtsYW5ndWFnZTogJ0VOJywgY291bnRyeTogJ1VTJ30sCiAgICAgIHB1YmxpY1N0b3JlZnJvbnRUb2tlbjogZW52LlBVQkxJQ19TVE9SRUZST05UX0FQSV9UT0tFTiwKICAgICAgcHJpdmF0ZVN0b3JlZnJvbnRUb2tlbjogZW52LlBSSVZBVEVfU1RPUkVGUk9OVF9BUElfVE9LRU4sCiAgICAgIHN0b3JlRG9tYWluOiBgaHR0cHM6Ly8ke2Vudi5QVUJMSUNfU1RPUkVfRE9NQUlOfWAsCiAgICAgIHN0b3JlZnJvbnRBcGlWZXJzaW9uOiBlbnYuUFVCTElDX1NUT1JFRlJPTlRfQVBJX1ZFUlNJT04gfHwgJzIwMjMtMDEnLAogICAgICBzdG9yZWZyb250SWQ6IGVudi5QVUJMSUNfU1RPUkVGUk9OVF9JRCwKLSAgICAgcmVxdWVzdEdyb3VwSWQ6IHJlcXVlc3QuaGVhZGVycy5nZXQoJ3JlcXVlc3QtaWQnKSwKKyAgICAgc3RvcmVmcm9udEhlYWRlcnM6IGdldFN0b3JlZnJvbnRIZWFkZXJzKHJlcXVlc3QpLAogICAgfSk7CmBgYA==',
          file: 'server.ts',
        },
      ],
    },
  ],
  features: [
    {
      title:
        'Add command to pull environment variables from a Hydrogen storefront',
      pr: 'https://github.com/Shopify/hydrogen/pull/809',
      id: '809',
    },
    {
      title:
        'New --debug flag for the dev command that attaches a Node inspector to the development server',
      pr: 'https://github.com/Shopify/hydrogen/pull/869',
      id: '869',
    },
    {
      title:
        'Add new commands for merchants to be able to list and link Hydrogen storefronts',
      pr: 'https://github.com/Shopify/hydrogen/pull/784',
      id: '784',
    },
    {
      title: 'Added parseGid() utility',
      pr: 'https://github.com/Shopify/hydrogen/pull/845',
      id: '845',
      steps: [
        {
          title: 'Example usage',
          code: 'YGBgdHMKaW1wb3J0IHtwYXJzZUdpZH0gZnJvbSAnQHNob3BpZnkvaHlkcm9nZW4tcmVhY3QnOwoKY29uc3Qge2lkLCByZXNvdXJjZX0gPSBwYXJzZUdpZCgnZ2lkOi8vc2hvcGlmeS9PcmRlci8xMjMnKTsKCmNvbnNvbGUubG9nKGlkKTsgLy8gMTIzCmNvbnNvbGUubG9nKHJlc291cmNlKTsgLy8gT3JkZXIKYGBg',
        },
      ],
    },
    {
      title:
        'Added a new shortcut command that creates a global h2 alias for the Hydrogen CLI',
      pr: 'https://github.com/Shopify/hydrogen/pull/679',
      id: '679',
      steps: [
        {
          title: 'Create the h2 alias',
          code: 'YGBgYmFzaApucHggc2hvcGlmeSBoeWRyb2dlbiBzaG9ydGN1dApgYGA=',
        },
        {
          title: 'After that, you can run commands using the new alias:',
          code: 'YGBgYmFzaApoMiBnZW5lcmF0ZSByb3V0ZSBob21lCmgyIGcgciBob21lICMgU2FtZSBhcyB0aGUgYWJvdmUKaDIgY2hlY2sgcm91dGVzCmBgYA==',
        },
      ],
    },
    {
      title: 'Add an experimental createWithCache_unstable',
      info: 'This utility creates a function similar to useQuery from Hydrogen v1. Use this utility to query third-party APIs and apply custom cache options',
      pr: 'https://github.com/Shopify/hydrogen/pull/600',
      id: '600',
      steps: [
        {
          title: 'To setup the utility, update your server.ts',
          file: 'server.ts',
          code: 'YGBgdHMKaW1wb3J0IHsKICBjcmVhdGVTdG9yZWZyb250Q2xpZW50LAogIGNyZWF0ZVdpdGhDYWNoZV91bnN0YWJsZSwKICBDYWNoZUxvbmcsCn0gZnJvbSAnQHNob3BpZnkvaHlkcm9nZW4nOwoKLy8gLi4uCgogIGNvbnN0IGNhY2hlID0gYXdhaXQgY2FjaGVzLm9wZW4oJ2h5ZHJvZ2VuJyk7CiAgY29uc3Qgd2l0aENhY2hlID0gY3JlYXRlV2l0aENhY2hlX3Vuc3RhYmxlKHtjYWNoZSwgd2FpdFVudGlsfSk7CgogIC8vIENyZWF0ZSBjdXN0b20gdXRpbGl0aWVzIHRvIHF1ZXJ5IHRoaXJkLXBhcnR5IEFQSXM6CiAgY29uc3QgZmV0Y2hNeUNNUyA9IChxdWVyeSkgPT4gewogICAgLy8gUHJlZml4IHRoZSBjYWNoZSBrZXkgYW5kIG1ha2UgaXQgdW5pcXVlIGJhc2VkIG9uIGFyZ3VtZW50cy4KICAgIHJldHVybiB3aXRoQ2FjaGUoWydteS1jbXMnLCBxdWVyeV0sIENhY2hlTG9uZygpLCAoKSA9PiB7CiAgICAgIGNvbnN0IGNtc0RhdGEgPSBhd2FpdCAoYXdhaXQgZmV0Y2goJ215LWNtcy5jb20vYXBpJywgewogICAgICAgIG1ldGhvZDogJ1BPU1QnLAogICAgICAgIGJvZHk6IHF1ZXJ5CiAgICAgIH0pKS5qc29uKCk7CgogICAgICBjb25zdCBuZXh0UGFnZSA9IChhd2FpdCBmZXRjaCgnbXktY21zLmNvbS9hcGknLCB7CiAgICAgICAgbWV0aG9kOiAnUE9TVCcsCiAgICAgICAgYm9keTogY21zRGF0YTEubmV4dFBhZ2VRdWVyeSwKICAgICAgfSkpLmpzb24oKTsKCiAgICAgIHJldHVybiB7Li4uY21zRGF0YSwgbmV4dFBhZ2V9CiAgICB9KTsKICB9OwoKICBjb25zdCBoYW5kbGVSZXF1ZXN0ID0gY3JlYXRlUmVxdWVzdEhhbmRsZXIoewogICAgYnVpbGQ6IHJlbWl4QnVpbGQsCiAgICBtb2RlOiBwcm9jZXNzLmVudi5OT0RFX0VOViwKICAgIGdldExvYWRDb250ZXh0OiAoKSA9PiAoewogICAgICBzZXNzaW9uLAogICAgICB3YWl0VW50aWwsCiAgICAgIHN0b3JlZnJvbnQsCiAgICAgIGVudiwKICAgICAgZmV0Y2hNeUNNUywKICAgIH0pLAogIH0pOwpgYGA=',
        },
      ],
    },
    {
      title: 'Update Remix to 1.14.0',
      pr: 'https://github.com/Shopify/hydrogen/pull/599',
      id: '599',
    },
    {
      title: 'Added Cache-Control defaults to all the demo store routes',
      pr: 'https://github.com/Shopify/hydrogen/pull/599',
      id: '599',
    },
    {
      title: 'Added new loader API for setting SEO tags within route module',
      pr: 'https://github.com/Shopify/hydrogen/pull/591',
      id: '591',
    },
    {
      title: 'ShopPayButton component now can receive a storeDomain',
      pr: 'https://github.com/Shopify/hydrogen/pull/645',
      id: '645',
    },
    {
      title:
        'Added robots option to SEO config that allows users granular control over the robots meta tag.',
      pr: 'https://github.com/Shopify/hydrogen/pull/572',
      id: '572',
      steps: [
        {
          title: 'Example usage',
          code: 'YGBgdHMKZXhwb3J0IGhhbmRsZSA9IHsKICBzZW86IHsKICAgIHJvYm90czogewogICAgICBub0luZGV4OiBmYWxzZSwKICAgICAgbm9Gb2xsb3c6IGZhbHNlLAogICAgfQogIH0KfQpgYGA=',
          file: 'All files that use SEO config',
        },
      ],
    },
    {
      title: 'Added decoding prop to the SpreadMedia component',
      pr: 'https://github.com/Shopify/hydrogen/pull/642',
      id: '642',
    },
  ],
  removeDependencies: [],
  removeDevDependencies: [],
  dependencies: {},
  devDependencies: {},
} as CumulativeRelease;

describe('dependency removal', () => {
  it('removes specified dependencies before upgrading', async () => {
    const selectedRelease: Release = {
      title: 'Remix to React Router migration',
      version: '2025.5.0',
      hash: 'abc123',
      commit: 'https://github.com/Shopify/hydrogen/pull/2961',
      pr: 'https://github.com/Shopify/hydrogen/pull/2961',
      date: '2025-01-21',
      dependencies: {
        '@shopify/hydrogen': '2025.5.0',
        'react-router': '7.6.0',
        'react-router-dom': '7.6.0',
      },
      devDependencies: {
        '@react-router/dev': '7.6.0',
      },
      removeDependencies: [
        '@remix-run/react',
        '@remix-run/server-runtime',
        '@shopify/hydrogen',
      ],
      removeDevDependencies: ['@remix-run/dev', '@remix-run/fs-routes'],
      dependenciesMeta: {},
      fixes: [],
      features: [],
    };

    const currentDependencies = {
      '@shopify/hydrogen': '2025.4.0',
      '@remix-run/react': '2.16.1',
      '@remix-run/server-runtime': '2.16.1',
      '@remix-run/dev': '2.16.1',
      '@remix-run/fs-routes': '2.16.1',
      react: '^18.2.0',
    };

    const args = buildUpgradeCommandArgs({
      selectedRelease,
      currentDependencies,
    });

    // Should include new packages to install but not removed packages
    expect(args).toEqual([
      '@shopify/hydrogen@2025.5.0',
      'react-router@7.6.0',
      'react-router-dom@7.6.0',
      '@react-router/dev@7.6.0',
      '@react-router/fs-routes@7.6.0',
    ]);
  });

  it('handles empty remove dependencies arrays', async () => {
    const selectedRelease: Release = {
      title: 'Normal upgrade',
      version: '2025.4.1',
      hash: 'def456',
      commit: 'https://github.com/Shopify/hydrogen/pull/2950',
      pr: 'https://github.com/Shopify/hydrogen/pull/2950',
      date: '2025-01-15',
      dependencies: {
        '@shopify/hydrogen': '2025.4.1',
      },
      devDependencies: {},
      removeDependencies: [],
      removeDevDependencies: [],
      dependenciesMeta: {},
      fixes: [],
      features: [],
    };

    const currentDependencies = {
      '@shopify/hydrogen': '2025.4.0',
      react: '^18.2.0',
    };

    const args = buildUpgradeCommandArgs({
      selectedRelease,
      currentDependencies,
    });

    expect(args).toEqual(['@shopify/hydrogen@2025.4.1']);
  });

  it('handles migration with React Router dependency detection', async () => {
    const selectedRelease: Release = {
      title: 'React Router 7 migration with removal',
      version: '2025.5.0',
      hash: 'ghi789',
      commit: 'https://github.com/Shopify/hydrogen/pull/2961',
      pr: 'https://github.com/Shopify/hydrogen/pull/2961',
      date: '2025-01-21',
      dependencies: {
        '@shopify/hydrogen': '2025.5.0',
        'react-router': '7.6.0',
        'react-router-dom': '7.6.0',
      },
      devDependencies: {
        '@react-router/dev': '7.6.0',
        '@react-router/fs-routes': '7.6.0',
      },
      removeDependencies: ['@remix-run/react', '@shopify/hydrogen'],
      removeDevDependencies: ['@remix-run/dev'],
      dependenciesMeta: {},
      fixes: [],
      features: [],
    };

    // Current project has Remix dependencies but no React Router
    const currentDependencies = {
      '@shopify/hydrogen': '2025.4.0',
      '@remix-run/react': '2.16.1',
      '@remix-run/dev': '2.16.1',
      react: '^18.2.0',
    };

    const args = buildUpgradeCommandArgs({
      selectedRelease,
      currentDependencies,
    });

    // Should install new React Router packages since we're migrating
    expect(args).toEqual([
      '@shopify/hydrogen@2025.5.0',
      'react-router@7.6.0',
      'react-router-dom@7.6.0',
      '@react-router/dev@7.6.0',
      '@react-router/fs-routes@7.6.0',
    ]);
  });

  it('handles missing dependencies in removeDependencies gracefully', async () => {
    const selectedRelease: Release = {
      title: 'Release with missing dependencies to remove',
      version: '2025.5.0',
      hash: 'xyz123',
      commit: 'https://github.com/Shopify/hydrogen/pull/2962',
      pr: 'https://github.com/Shopify/hydrogen/pull/2962',
      date: '2025-01-21',
      dependencies: {
        '@shopify/hydrogen': '2025.5.0',
      },
      devDependencies: {
        '@shopify/cli': '~3.80.0',
      },
      // Try to remove dependencies that don't exist in the current project
      removeDependencies: ['@some/missing-package', '@another/nonexistent-dep'],
      removeDevDependencies: ['@dev/missing-package'],
      dependenciesMeta: {},
      fixes: [],
      features: [],
    };

    // Current project has only basic dependencies - missing packages listed in removeDependencies
    const currentDependencies = {
      '@shopify/hydrogen': '2025.4.0',
      react: '^18.2.0',
      '@shopify/cli': '~3.79.0',
    };

    // Should not crash and should only include packages that need upgrading
    const args = buildUpgradeCommandArgs({
      selectedRelease,
      currentDependencies,
    });

    // Should upgrade existing packages, ignore missing ones in removeDependencies
    expect(args).toEqual(['@shopify/hydrogen@2025.5.0', '@shopify/cli@3.80.0']);
  });
});

describe('--version=next functionality', () => {
  describe('monorepo-only restrictions', () => {
    it('should allow --version=next in tests and CI environments', async () => {
      await inTemporaryHydrogenRepo(
        async (appPath) => {
          // This should work because SHOPIFY_UNIT_TEST=1 is set in test environment
          // and our logic allows --version=next in tests/CI even outside monorepo
          await expect(
            runUpgrade({
              appPath,
              version: 'next',
              force: false,
            }),
          ).resolves.toBeUndefined();
        },
        {
          cleanGitRepo: true,
          packageJson: {
            dependencies: {
              '@shopify/hydrogen': '2025.4.0',
            },
          },
        },
      );
    });
  });

  it('handles getAbsoluteVersion with next versions', () => {
    expect(getAbsoluteVersion('next')).toBe('next');
    expect(getAbsoluteVersion('^0.0.0-next-abc123-20250925')).toBe(
      '0.0.0-next-abc123-20250925',
    );
  });

  it('getPackageVersion transforms @shopify packages when targetVersion is next', () => {
    expect(getPackageVersion('@shopify/hydrogen', '2025.7.0', 'next')).toBe(
      'next',
    );
    expect(getPackageVersion('@shopify/mini-oxygen', '4.0.0', 'next')).toBe(
      'next',
    );
    expect(getPackageVersion('@shopify/cli', '3.83.3', 'next')).toBe('3.83.3');
    expect(getPackageVersion('react-router', '7.9.2', 'next')).toBe('7.9.2');
    expect(getPackageVersion('@shopify/hydrogen', '2025.7.0')).toBe('2025.7.0');
  });

  describe('createNextRelease function', () => {
    it('should create synthetic release with next versions for @shopify packages', async () => {
      const currentDependencies = {
        '@shopify/hydrogen': '2025.4.0',
        '@shopify/mini-oxygen': '3.2.0',
      };

      const latestRelease = {
        title: 'Latest release',
        version: '2025.7.0',
        hash: 'abc123',
        commit: 'https://github.com/test' as `https://${string}`,
        pr: 'https://github.com/test' as `https://${string}`,
        date: '2025-09-17',
        dependencies: {
          '@shopify/hydrogen': '2025.7.0',
          'react-router': '7.9.2',
        },
        devDependencies: {
          '@shopify/mini-oxygen': '4.0.0',
          '@shopify/cli': '3.83.3',
        },
        fixes: [{title: 'Test fix', id: '123', pr: null}],
        features: [{title: 'Test feature', id: '456', pr: null}],
      } as Release;

      const result = await getSelectedRelease({
        targetVersion: 'next',
        availableUpgrades: [latestRelease],
        currentVersion: '2025.4.0',
        currentDependencies,
      });

      expect(result.dependencies['@shopify/hydrogen']).toBe('next');
      expect(result.devDependencies?.['@shopify/mini-oxygen']).toBe('next');
      expect(result.dependencies['react-router']).toBe('7.9.2');
      expect(result.title).toContain('(next versions)');
    });
  });

  describe('getSelectedRelease with --version=next', () => {
    it('should create synthetic next release when targetVersion is next', async () => {
      const availableUpgrades = [
        {
          title: 'Latest release',
          version: '2025.7.0',
          hash: 'abc123',
          commit: 'https://github.com/test' as `https://${string}`,
          pr: 'https://github.com/test' as `https://${string}`,
          date: '2025-09-17',
          dependencies: {
            '@shopify/hydrogen': '2025.7.0',
            'react-router': '7.9.2',
          },
          devDependencies: {
            '@shopify/mini-oxygen': '4.0.0',
            '@shopify/cli': '3.83.3',
          },
          fixes: [],
          features: [],
        } as Release,
      ];

      const currentDependencies = {
        '@shopify/hydrogen': '2025.4.0',
        '@shopify/mini-oxygen': '3.2.0',
      };

      const result = await getSelectedRelease({
        targetVersion: 'next',
        availableUpgrades,
        currentVersion: '2025.4.0',
        currentDependencies,
      });

      expect(result.dependencies['@shopify/hydrogen']).toBe('next');
      expect(result.devDependencies?.['@shopify/mini-oxygen']).toBe('next');
      expect(result.dependencies['react-router']).toBe('7.9.2'); // Non-Shopify packages unchanged
    });

    it('should find regular release when targetVersion is specific version', async () => {
      const availableUpgrades = [
        {
          title: 'Test release',
          version: '2025.7.0',
          hash: 'test-hash',
          commit: 'https://github.com/test' as `https://${string}`,
          pr: 'https://github.com/test' as `https://${string}`,
          date: '2025-09-17',
          dependencies: {},
          devDependencies: {},
          fixes: [],
          features: [],
        },
      ];

      const result = await getSelectedRelease({
        targetVersion: '2025.7.0',
        availableUpgrades,
        currentVersion: '2025.4.0',
        currentDependencies: {},
      });

      expect(result.version).toBe('2025.7.0');
    });

    it('preserves dependency removals in cumulative release for synthetic next upgrades', async () => {
      const latestRelease = {
        title: 'Latest release',
        version: '2025.7.0',
        hash: 'abc123',
        commit: 'https://github.com/test' as `https://${string}`,
        pr: 'https://github.com/test' as `https://${string}`,
        date: '2025-09-17',
        dependencies: {
          '@shopify/hydrogen': '2025.7.0',
          'react-router': '7.9.2',
        },
        devDependencies: {
          '@shopify/mini-oxygen': '4.0.0',
        },
        removeDependencies: ['@remix-run/react'],
        removeDevDependencies: ['@remix-run/dev'],
        fixes: [],
        features: [],
      } as Release;

      const selectedRelease = await getSelectedRelease({
        targetVersion: 'next',
        availableUpgrades: [latestRelease],
        currentVersion: '2025.4.0',
        currentDependencies: {'@shopify/hydrogen': '2025.4.0'},
      });

      const cumulativeRelease = getCumulativeRelease({
        availableUpgrades: [latestRelease],
        selectedRelease,
        currentVersion: '2025.4.0',
      });

      expect(cumulativeRelease.removeDependencies).toEqual([
        '@remix-run/react',
      ]);
      expect(cumulativeRelease.removeDevDependencies).toEqual([
        '@remix-run/dev',
      ]);
    });
  });

  describe('buildUpgradeCommandArgs with --version=next', () => {
    it('should transform @shopify packages to next when targetVersion is next', () => {
      const testRelease = {
        title: 'Test release',
        version: '2025.7.0',
        hash: 'test',
        commit: 'https://github.com/test' as `https://${string}`,
        pr: 'https://github.com/test' as `https://${string}`,
        date: '2025-09-17',
        dependencies: {
          '@shopify/hydrogen': '2025.7.0',
          'react-router': '7.9.2',
        },
        devDependencies: {
          '@shopify/mini-oxygen': '4.0.0',
          '@shopify/cli': '3.83.3',
        },
        dependenciesMeta: {},
        fixes: [],
        features: [],
      } satisfies Release;

      const currentDependencies = {
        '@shopify/hydrogen': '2025.4.0',
        '@shopify/mini-oxygen': '3.2.0',
        'react-router': '7.0.0',
        '@shopify/cli': '3.82.0',
      };

      const args = buildUpgradeCommandArgs({
        selectedRelease: testRelease,
        currentDependencies,
        targetVersion: 'next',
      });

      expect(args).toContain('@shopify/hydrogen@next');
      expect(args).toContain('@shopify/mini-oxygen@next');
      expect(args).toContain('@shopify/cli@3.83.3'); // Non-targeted Shopify packages use semver
      expect(args).toContain('react-router@7.9.2'); // Non-Shopify packages unchanged
    });

    it('should not transform packages when targetVersion is not next', () => {
      const testRelease = {
        title: 'Test release',
        version: '2025.7.0',
        hash: 'test-hash',
        commit: 'https://github.com/test' as `https://${string}`,
        pr: 'https://github.com/test' as `https://${string}`,
        date: '2025-09-17',
        dependencies: {
          '@shopify/hydrogen': '2025.7.0',
        },
        devDependencies: {
          '@shopify/mini-oxygen': '4.0.0',
        },
        dependenciesMeta: {},
        fixes: [],
        features: [],
      };

      const currentDependencies = {
        '@shopify/hydrogen': '2025.4.0',
        '@shopify/mini-oxygen': '3.2.0',
      };

      const args = buildUpgradeCommandArgs({
        selectedRelease: testRelease,
        currentDependencies,
        // No targetVersion specified
      });

      expect(args).toContain('@shopify/hydrogen@2025.7.0');
      expect(args).toContain('@shopify/mini-oxygen@4.0.0');
      expect(args).not.toContain('@shopify/hydrogen@next');
      expect(args).not.toContain('@shopify/mini-oxygen@next');
    });
  });

  describe('displayConfirmation with --version=next', () => {
    it('should skip confirmation when targetVersion is next', () => {
      const cumulativeRelease = {
        features: [],
        fixes: [],
        removeDependencies: [],
        removeDevDependencies: [],
        dependencies: {},
        devDependencies: {},
      };

      const selectedRelease = {
        version: '2025.7.0',
      } as Release;

      const result = displayConfirmation({
        cumulativeRelease,
        selectedRelease,
        targetVersion: 'next',
      });

      expect(result).toBe(true); // Should skip confirmation
    });

    it('should show confirmation when targetVersion is not next', async () => {
      const cumulativeRelease = {
        features: [],
        fixes: [],
        removeDependencies: [],
        removeDevDependencies: [],
        dependencies: {},
        devDependencies: {},
      };

      const selectedRelease = {
        version: '2025.7.0',
      } as Release;

      await displayConfirmation({
        cumulativeRelease,
        selectedRelease,
        // No targetVersion specified
      });

      expect(renderConfirmationPrompt).toHaveBeenCalled();
    });
  });

  describe('validateUpgrade with snapshot versions', () => {
    it('should accept snapshot versions when targetVersion is next', async () => {
      await inTemporaryHydrogenRepo(
        async (appPath) => {
          const packageJson = {
            dependencies: {
              '@shopify/hydrogen': '^0.0.0-next-abc123-20250925',
            },
          };

          await writeFile(
            joinPath(appPath, 'package.json'),
            JSON.stringify(packageJson, null, 2),
          );

          const release = {
            title: 'Test release',
            version: '2025.7.0',
            hash: 'test',
            commit: 'https://github.com/test' as `https://${string}`,
            pr: 'https://github.com/test' as `https://${string}`,
            date: '2025-09-17',
            dependencies: {'@shopify/hydrogen': 'next'},
            devDependencies: {},
            fixes: [],
            features: [],
          } satisfies Release;

          await expect(
            validateUpgrade({
              appPath,
              selectedRelease: release,
              targetVersion: 'next',
            }),
          ).resolves.toBeUndefined();
        },
        {cleanGitRepo: false},
      );
    });

    it('should reject snapshot versions when targetVersion is not next', async () => {
      await inTemporaryHydrogenRepo(
        async (appPath) => {
          const packageJson = {
            dependencies: {
              '@shopify/hydrogen': '^0.0.0-next-abc123-20250925',
            },
          };

          await writeFile(
            joinPath(appPath, 'package.json'),
            JSON.stringify(packageJson, null, 2),
          );

          const release = {
            title: 'Test release',
            version: '2025.7.0',
            hash: 'test-hash',
            commit: 'https://github.com/test' as `https://${string}`,
            pr: 'https://github.com/test' as `https://${string}`,
            date: '2025-09-17',
            dependencies: {'@shopify/hydrogen': '2025.7.0'},
            devDependencies: {},
            fixes: [],
            features: [],
          };

          await expect(
            validateUpgrade({appPath, selectedRelease: release}),
          ).rejects.toThrow();
        },
        {cleanGitRepo: false},
      );
    });
  });

  describe('end-to-end --version=next command simulation', () => {
    it('should complete full upgrade flow with --version=next', async () => {
      await inTemporaryHydrogenRepo(
        async (appPath) => {
          const mockUpgrade = {
            appPath,
            version: 'next',
            force: false,
          };

          await expect(runUpgrade(mockUpgrade)).resolves.toBeUndefined();
        },
        {
          cleanGitRepo: true,
          packageJson: {
            dependencies: {
              '@shopify/hydrogen': '2025.4.0',
            },
          },
        },
      );
    });
  });
});
