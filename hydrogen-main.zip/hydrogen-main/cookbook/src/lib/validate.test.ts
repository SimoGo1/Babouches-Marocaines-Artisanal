import {describe, expect, it, vi, beforeEach, afterEach, Mock} from 'vitest';
import {Recipe} from './recipe';
import {
  validateStepNames,
  validateStepDescriptions,
  validatePatchFiles,
  validateIngredientFiles,
  validateReadmeExists,
  validateLlmPromptExists,
  getYamlLineNumber,
  validateRecipe,
  formatValidationError,
} from './validate';
import {
  resolveCatalogProtocol,
  withResolvedCatalog,
  _resetWorkspaceVersionsCache,
} from './workspace';
import {execFileSync} from 'child_process';
import fs from 'fs';
import path from 'path';
import {COOKBOOK_PATH, REPO_ROOT, TEMPLATE_PATH} from './constants';
import * as recipeModule from './recipe';

vi.mock('./apply', () => ({
  applyRecipe: vi.fn(),
}));

vi.mock('child_process', () => ({
  execSync: vi.fn(() =>
    Buffer.from('/Users/juanp.prieto/github.com/Shopify/hydrogen'),
  ),
  execFileSync: vi.fn(),
}));

describe('formatValidationError', () => {
  it('should format error with line number and location', () => {
    const error = {
      validator: 'RecipeSchema',
      message: 'Invalid input: expected string, received number',
      location: 'steps.0.step',
      lineNumber: 52,
    };

    const formatted = formatValidationError(error);

    expect(formatted).toContain('recipe.yaml:52');
    expect(formatted).toContain('steps.0.step');
    expect(formatted).toContain(
      'RecipeSchema: Invalid input: expected string, received number',
    );
  });

  it('should format error without line number', () => {
    const error = {
      validator: 'validateReadmeExists',
      message: 'README.md not found',
      location: 'README.md',
    };

    const formatted = formatValidationError(error);

    expect(formatted).not.toContain('recipe.yaml');
    expect(formatted).toContain('README.md');
    expect(formatted).toContain('validateReadmeExists: README.md not found');
  });

  it('should format error without location', () => {
    const error = {
      validator: 'validateLlmPromptExists',
      message: 'LLM prompt file not found',
    };

    const formatted = formatValidationError(error);

    expect(formatted).toContain(
      'validateLlmPromptExists: LLM prompt file not found',
    );
  });
});

describe('getYamlLineNumber', () => {
  const mockYamlContent = `# yaml-language-server: $schema=../../recipe.schema.json

gid: test-gid
title: Test Recipe
summary: Test
description: Test
ingredients: []
steps:
  - step: "1"
    type: PATCH
    name: README.md
    description: Test
    diffs: []
  - step: "2"
    type: PATCH
    name: app/root.tsx
    description: Test
    diffs: []
commit: abc123
`;

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('should return line number for simple field', () => {
    const yamlPath = path.join(COOKBOOK_PATH, 'recipes', 'test', 'recipe.yaml');

    vi.spyOn(fs, 'readFileSync').mockReturnValue(mockYamlContent);

    const lineNum = getYamlLineNumber(yamlPath, ['title']);

    expect(lineNum).toBeGreaterThan(0);
    expect(lineNum).toBeLessThan(10);
  });

  it('should return line number for nested array element', () => {
    const yamlPath = path.join(COOKBOOK_PATH, 'recipes', 'test', 'recipe.yaml');

    vi.spyOn(fs, 'readFileSync').mockReturnValue(mockYamlContent);

    const lineNum = getYamlLineNumber(yamlPath, ['steps', 0, 'step']);

    expect(lineNum).toBeGreaterThan(8);
  });

  it('should return null for invalid path', () => {
    const yamlPath = path.join(COOKBOOK_PATH, 'recipes', 'test', 'recipe.yaml');

    vi.spyOn(fs, 'readFileSync').mockReturnValue(mockYamlContent);

    const lineNum = getYamlLineNumber(yamlPath, ['nonexistent', 'path']);

    expect(lineNum).toBeNull();
  });

  it('should return null for nonexistent file', () => {
    vi.spyOn(fs, 'readFileSync').mockImplementation(() => {
      throw new Error('File not found');
    });

    const lineNum = getYamlLineNumber('/nonexistent/file.yaml', ['title']);

    expect(lineNum).toBeNull();
  });
});

describe('validateStepNames', () => {
  it('should return error when steps have duplicate numbers', () => {
    const recipe: Recipe = {
      gid: 'test-gid',
      title: 'Test',
      summary: 'Test',
      description: 'Test',
      ingredients: [],
      steps: [
        {type: 'PATCH' as const, step: '1', name: 'README.md', diffs: []},
        {type: 'PATCH' as const, step: '1', name: 'app/root.tsx', diffs: []},
      ],
      commit: 'abc123',
      llms: {userQueries: [], troubleshooting: []},
    };

    const result = validateStepNames(recipe);

    expect(result.valid).toBe(false);
    expect(result.errors).toHaveLength(1);
    expect(result.errors[0]).toMatchObject({
      validator: 'validateStepNames',
      message:
        'Duplicate step number "1". Use substeps (e.g., "1.1", "1.2") to organize related changes under step 1.',
      location: 'steps[1].step',
    });
  });

  it('should return valid for sequential steps', () => {
    const recipe: Recipe = {
      gid: 'test-gid',
      title: 'Test',
      summary: 'Test',
      description: 'Test',
      ingredients: [],
      steps: [
        {type: 'PATCH' as const, step: '1', name: 'README.md', diffs: []},
        {type: 'PATCH' as const, step: '2', name: 'app/root.tsx', diffs: []},
      ],
      commit: 'abc123',
      llms: {userQueries: [], troubleshooting: []},
    };

    const result = validateStepNames(recipe);

    expect(result.valid).toBe(true);
    expect(result.errors).toHaveLength(0);
  });

  it('should return valid for substeps', () => {
    const recipe: Recipe = {
      gid: 'test-gid',
      title: 'Test',
      summary: 'Test',
      description: 'Test',
      ingredients: [],
      steps: [
        {type: 'PATCH' as const, step: '1', name: 'README.md', diffs: []},
        {
          type: 'PATCH' as const,
          step: '1.1',
          name: 'app/entry.server.tsx',
          diffs: [],
        },
        {type: 'PATCH' as const, step: '1.2', name: 'app/root.tsx', diffs: []},
      ],
      commit: 'abc123',
      llms: {userQueries: [], troubleshooting: []},
    };

    const result = validateStepNames(recipe);

    expect(result.valid).toBe(true);
    expect(result.errors).toHaveLength(0);
  });

  it('should reject duplicate main step numbers even with different names', () => {
    const recipe: Recipe = {
      gid: 'test-gid',
      title: 'Test',
      summary: 'Test',
      description: 'Test',
      ingredients: [],
      steps: [
        {type: 'PATCH' as const, step: '1', name: 'README.md', diffs: []},
        {type: 'PATCH' as const, step: '1', name: 'app/root.tsx', diffs: []},
      ],
      commit: 'abc123',
      llms: {userQueries: [], troubleshooting: []},
    };

    const result = validateStepNames(recipe);

    expect(result.valid).toBe(false);
    expect(result.errors).toHaveLength(1);
    expect(result.errors[0]).toMatchObject({
      validator: 'validateStepNames',
      message:
        'Duplicate step number "1". Use substeps (e.g., "1.1", "1.2") to organize related changes under step 1.',
      location: 'steps[1].step',
    });
  });

  it('should reject duplicate substep numbers', () => {
    const recipe: Recipe = {
      gid: 'test-gid',
      title: 'Test',
      summary: 'Test',
      description: 'Test',
      ingredients: [],
      steps: [
        {type: 'PATCH' as const, step: '1.1', name: 'FileA.tsx', diffs: []},
        {type: 'PATCH' as const, step: '1.1', name: 'FileB.tsx', diffs: []},
      ],
      commit: 'abc123',
      llms: {userQueries: [], troubleshooting: []},
    };

    const result = validateStepNames(recipe);

    expect(result.valid).toBe(false);
    expect(result.errors).toHaveLength(1);
    expect(result.errors[0]).toMatchObject({
      validator: 'validateStepNames',
      message:
        'Duplicate step number "1.1". Each step must have a unique step number.',
      location: 'steps[1].step',
    });
  });

  it('should allow proper substep hierarchy', () => {
    const recipe: Recipe = {
      gid: 'test-gid',
      title: 'Test',
      summary: 'Test',
      description: 'Test',
      ingredients: [],
      steps: [
        {type: 'INFO' as const, step: '1', name: 'Setup configuration'},
        {type: 'PATCH' as const, step: '1.1', name: 'README.md', diffs: []},
        {type: 'PATCH' as const, step: '1.2', name: 'app/root.tsx', diffs: []},
        {type: 'PATCH' as const, step: '2', name: 'package.json', diffs: []},
      ],
      commit: 'abc123',
      llms: {userQueries: [], troubleshooting: []},
    };

    const result = validateStepNames(recipe);

    expect(result.valid).toBe(true);
    expect(result.errors).toHaveLength(0);
  });

  it('should reject "1.0" as duplicate of "1"', () => {
    const recipe: Recipe = {
      gid: 'test-gid',
      title: 'Test',
      summary: 'Test',
      description: 'Test',
      ingredients: [],
      steps: [
        {type: 'PATCH' as const, step: '1', name: 'FileA', diffs: []},
        {type: 'PATCH' as const, step: '1.0', name: 'FileB', diffs: []},
      ],
      commit: 'abc123',
      llms: {userQueries: [], troubleshooting: []},
    };

    const result = validateStepNames(recipe);

    expect(result.valid).toBe(false);
    expect(result.errors).toHaveLength(1);
    expect(result.errors[0].message).toContain('Duplicate step number');
  });

  it('should reject leading zero duplicates', () => {
    const recipe: Recipe = {
      gid: 'test-gid',
      title: 'Test',
      summary: 'Test',
      description: 'Test',
      ingredients: [],
      steps: [
        {type: 'PATCH' as const, step: '1', name: 'FileA', diffs: []},
        {type: 'PATCH' as const, step: '01', name: 'FileB', diffs: []},
      ],
      commit: 'abc123',
      llms: {userQueries: [], troubleshooting: []},
    };

    const result = validateStepNames(recipe);

    expect(result.valid).toBe(false);
    expect(result.errors).toHaveLength(1);
    expect(result.errors[0].message).toContain('Duplicate step number');
  });
});

describe('validateStepDescriptions', () => {
  it('should return error when step description is null', () => {
    const recipe: Recipe = {
      gid: 'test-gid',
      title: 'Test',
      summary: 'Test',
      description: 'Test',
      ingredients: [],
      steps: [
        {
          type: 'PATCH' as const,
          step: '1',
          name: 'README.md',
          description: null,
          diffs: [],
        },
      ],
      commit: 'abc123',
      llms: {userQueries: [], troubleshooting: []},
    };

    const result = validateStepDescriptions(recipe);

    expect(result.valid).toBe(false);
    expect(result.errors).toHaveLength(1);
    expect(result.errors[0]).toMatchObject({
      validator: 'validateStepDescriptions',
      message:
        'Step 1 (README.md) has null description. Please provide a description for this step.',
      location: 'steps[0].description',
    });
  });

  it('should return error when step description is empty string', () => {
    const recipe: Recipe = {
      gid: 'test-gid',
      title: 'Test',
      summary: 'Test',
      description: 'Test',
      ingredients: [],
      steps: [
        {
          type: 'PATCH' as const,
          step: '1',
          name: 'app/root.tsx',
          description: '',
          diffs: [],
        },
      ],
      commit: 'abc123',
      llms: {userQueries: [], troubleshooting: []},
    };

    const result = validateStepDescriptions(recipe);

    expect(result.valid).toBe(false);
    expect(result.errors).toHaveLength(1);
    expect(result.errors[0]).toMatchObject({
      validator: 'validateStepDescriptions',
      message:
        'Step 1 (app/root.tsx) has empty description. Please provide a description for this step.',
      location: 'steps[0].description',
    });
  });

  it('should return valid result when all descriptions are present', () => {
    const recipe: Recipe = {
      gid: 'test-gid',
      title: 'Test',
      summary: 'Test',
      description: 'Test',
      ingredients: [],
      steps: [
        {
          type: 'PATCH' as const,
          step: '1',
          name: 'README.md',
          description: 'Valid description',
          diffs: [],
        },
      ],
      commit: 'abc123',
      llms: {userQueries: [], troubleshooting: []},
    };

    const result = validateStepDescriptions(recipe);

    expect(result.valid).toBe(true);
    expect(result.errors).toHaveLength(0);
  });
});

describe('validatePatchFiles', () => {
  let mockExistsSync: Mock;
  let mockReaddirSync: Mock;

  beforeEach(() => {
    mockExistsSync = vi.spyOn(fs, 'existsSync').mockReturnValue(true) as Mock;
    mockReaddirSync = vi.spyOn(fs, 'readdirSync').mockReturnValue([]) as Mock;
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('should return error when patch file referenced in yaml does not exist', () => {
    const recipe: Recipe = {
      gid: '550e8400-e29b-41d4-a716-446655440000',
      title: 'Test',
      summary: 'Test',
      description: 'Test',
      ingredients: [],
      steps: [
        {
          type: 'PATCH' as const,
          step: '1',
          name: 'app/root.tsx',
          description: 'Updates configuration',
          diffs: [{file: 'app/root.tsx', patchFile: 'root.tsx.abc123.patch'}],
        },
      ],
      commit: 'abc123',
      llms: {userQueries: [], troubleshooting: []},
    };

    mockExistsSync.mockImplementation((filePath: fs.PathLike) => {
      const pathStr = filePath.toString();
      if (pathStr.includes('patches')) return false;
      return true;
    });

    const result = validatePatchFiles('test-recipe', recipe);

    expect(result.valid).toBe(false);
    expect(result.errors).toHaveLength(1);
    expect(result.errors[0]).toMatchObject({
      validator: 'validatePatchFiles',
      message: 'Patch file not found: root.tsx.abc123.patch',
    });
  });

  it('should return error when patch file exists on filesystem but not referenced in yaml', () => {
    const recipe: Recipe = {
      gid: '550e8400-e29b-41d4-a716-446655440000',
      title: 'Test',
      summary: 'Test',
      description: 'Test',
      ingredients: [],
      steps: [],
      commit: 'abc123',
      llms: {userQueries: [], troubleshooting: []},
    };

    mockExistsSync.mockReturnValue(true);
    mockReaddirSync.mockReturnValue([
      {name: 'orphaned.patch', isFile: () => true} as fs.Dirent,
    ] as fs.Dirent[]);

    const result = validatePatchFiles('test-recipe', recipe);

    expect(result.valid).toBe(false);
    expect(result.errors).toHaveLength(1);
    expect(result.errors[0]).toMatchObject({
      validator: 'validatePatchFiles',
      message: 'Orphaned patch file not referenced in recipe: orphaned.patch',
    });
  });

  it('should return valid when all patch files are valid', () => {
    const recipe: Recipe = {
      gid: '550e8400-e29b-41d4-a716-446655440000',
      title: 'Test',
      summary: 'Test',
      description: 'Test',
      ingredients: [],
      steps: [
        {
          type: 'PATCH' as const,
          step: '1',
          name: 'app/root.tsx',
          description: 'Updates configuration',
          diffs: [{file: 'app/root.tsx', patchFile: 'root.tsx.abc123.patch'}],
        },
      ],
      commit: 'abc123',
      llms: {userQueries: [], troubleshooting: []},
    };

    mockExistsSync.mockReturnValue(true);
    mockReaddirSync.mockReturnValue([
      {name: 'root.tsx.abc123.patch', isFile: () => true} as fs.Dirent,
    ] as fs.Dirent[]);

    const result = validatePatchFiles('test-recipe', recipe);

    expect(result.valid).toBe(true);
    expect(result.errors).toHaveLength(0);
  });
});

describe('validateIngredientFiles', () => {
  let mockExistsSync: Mock;
  let mockReaddirSync: Mock;

  beforeEach(() => {
    mockExistsSync = vi.spyOn(fs, 'existsSync').mockReturnValue(true) as Mock;
    mockReaddirSync = vi.spyOn(fs, 'readdirSync').mockReturnValue([]) as Mock;
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('should return error when ingredient file referenced in yaml does not exist', () => {
    const recipe: Recipe = {
      gid: '550e8400-e29b-41d4-a716-446655440000',
      title: 'Test',
      summary: 'Test',
      description: 'Test',
      ingredients: [
        {path: 'templates/skeleton/app/components/Foo.tsx', description: null},
      ],
      steps: [],
      commit: 'abc123',
      llms: {userQueries: [], troubleshooting: []},
    };

    mockExistsSync.mockImplementation((filePath: fs.PathLike) => {
      const pathStr = filePath.toString();
      if (pathStr.includes('ingredients')) return false;
      return true;
    });

    const result = validateIngredientFiles('test-recipe', recipe);

    expect(result.valid).toBe(false);
    expect(result.errors).toHaveLength(1);
    expect(result.errors[0]).toMatchObject({
      validator: 'validateIngredientFiles',
      message:
        'Ingredient file not found: templates/skeleton/app/components/Foo.tsx',
    });
  });

  it('should return error when ingredient file exists on filesystem but not referenced in yaml', () => {
    const recipe: Recipe = {
      gid: '550e8400-e29b-41d4-a716-446655440000',
      title: 'Test',
      summary: 'Test',
      description: 'Test',
      ingredients: [],
      steps: [],
      commit: 'abc123',
      llms: {userQueries: [], troubleshooting: []},
    };

    mockExistsSync.mockReturnValue(true);

    const ingredientsDir = path.join(
      COOKBOOK_PATH,
      'recipes',
      'test-recipe',
      'ingredients',
    );

    mockReaddirSync.mockReturnValue([
      {
        path: ingredientsDir,
        name: 'orphaned.tsx',
        isFile: () => true,
      } as fs.Dirent,
    ] as fs.Dirent[]);

    const result = validateIngredientFiles('test-recipe', recipe);

    expect(result.valid).toBe(false);
    expect(result.errors).toHaveLength(1);
    expect(result.errors[0]).toMatchObject({
      validator: 'validateIngredientFiles',
      message:
        'Orphaned ingredient file not referenced in recipe: orphaned.tsx',
    });
  });

  it('should return valid when all ingredient files are valid', () => {
    const recipe: Recipe = {
      gid: '550e8400-e29b-41d4-a716-446655440000',
      title: 'Test',
      summary: 'Test',
      description: 'Test',
      ingredients: [
        {path: 'templates/skeleton/app/components/Foo.tsx', description: null},
      ],
      steps: [],
      commit: 'abc123',
      llms: {userQueries: [], troubleshooting: []},
    };

    mockExistsSync.mockReturnValue(true);

    const ingredientsDir = path.join(
      COOKBOOK_PATH,
      'recipes',
      'test-recipe',
      'ingredients',
    );

    mockReaddirSync.mockReturnValue([
      {
        path: path.join(
          ingredientsDir,
          'templates',
          'skeleton',
          'app',
          'components',
        ),
        name: 'Foo.tsx',
        isFile: () => true,
      } as fs.Dirent,
    ] as fs.Dirent[]);

    const result = validateIngredientFiles('test-recipe', recipe);

    expect(result.valid).toBe(true);
    expect(result.errors).toHaveLength(0);
  });
});

describe('validateReadmeExists', () => {
  let mockExistsSync: Mock;

  beforeEach(() => {
    mockExistsSync = vi.spyOn(fs, 'existsSync') as Mock;
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('should return valid for existing recipe with README', () => {
    mockExistsSync.mockReturnValue(true);
    const result = validateReadmeExists('gtm');

    expect(result.valid).toBe(true);
    expect(result.errors).toHaveLength(0);
  });

  it('should return error with render command when README missing', () => {
    mockExistsSync.mockReturnValue(false);
    const result = validateReadmeExists('nonexistent-recipe');

    expect(result.valid).toBe(false);
    expect(result.errors).toHaveLength(1);
    expect(result.errors[0]).toMatchObject({
      validator: 'validateReadmeExists',
      message: expect.stringContaining(
        'Run: pnpm run cookbook render nonexistent-recipe',
      ),
    });
  });
});

describe('validateLlmPromptExists', () => {
  let mockExistsSync: Mock;

  beforeEach(() => {
    mockExistsSync = vi.spyOn(fs, 'existsSync') as Mock;
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('should return valid for existing recipe with LLM prompt', () => {
    mockExistsSync.mockReturnValue(true);
    const result = validateLlmPromptExists('gtm');

    expect(result.valid).toBe(true);
    expect(result.errors).toHaveLength(0);
  });

  it('should return error with render command when LLM prompt missing', () => {
    mockExistsSync.mockReturnValue(false);
    const result = validateLlmPromptExists('nonexistent-recipe');

    expect(result.valid).toBe(false);
    expect(result.errors).toHaveLength(1);
    expect(result.errors[0]).toMatchObject({
      validator: 'validateLlmPromptExists',
      message: expect.stringContaining(
        'Run: pnpm run cookbook render nonexistent-recipe',
      ),
    });
  });
});

describe('validateRecipe integration', () => {
  let consoleErrorSpy: Mock;
  let mockExistsSync: Mock;
  let mockReaddirSync: Mock;
  let mockLoadRecipe: Mock;

  beforeEach(() => {
    consoleErrorSpy = vi
      .spyOn(console, 'error')
      .mockImplementation(() => {}) as Mock;
    mockExistsSync = vi.spyOn(fs, 'existsSync') as Mock;
    mockReaddirSync = vi.spyOn(fs, 'readdirSync') as Mock;
    mockLoadRecipe = vi.spyOn(recipeModule, 'loadRecipe') as Mock;
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('should include actual values in Zod validation error messages', () => {
    const recipeName = 'test-recipe';
    const recipeYamlPath = path.join(
      COOKBOOK_PATH,
      'recipes',
      recipeName,
      'recipe.yaml',
    );

    const yamlContent = `
gid: test-gid
title: Test
summary: Test
description: Test
ingredients: []
steps:
  - step: 1
    type: PATCH
    name: README.md
    description: Test
    diffs: []
  - step: 2
    type: PATCH
    name: app/root.tsx
    description: Test
    diffs: []
commit: abc123
`;

    vi.spyOn(fs, 'readFileSync').mockImplementation((filePath: any) => {
      if (filePath === recipeYamlPath) {
        return yamlContent;
      }
      throw new Error(`File not found: ${filePath}`);
    });

    vi.spyOn(fs, 'existsSync').mockReturnValue(true);

    const result = validateRecipe({recipeTitle: recipeName});

    expect(result).toBe(false);

    const errorOutput = consoleErrorSpy.mock.calls
      .map((call) => call[0])
      .join('\n');

    expect(errorOutput).toContain(
      'Invalid input: expected string, received number (actual value: 1)',
    );
    expect(errorOutput).toContain(
      'Invalid input: expected string, received number (actual value: 2)',
    );
  });

  it('should collect and format all validation errors with line numbers', () => {
    const recipeName = 'test-recipe';

    const mockRecipe: Recipe = {
      gid: '550e8400-e29b-41d4-a716-446655440000',
      title: 'Test Recipe',
      summary: 'Test',
      description: 'Test',
      ingredients: [],
      steps: [
        {
          type: 'PATCH' as const,
          step: '1',
          name: 'README.md',
          description: null,
          diffs: [
            {file: 'README.md', patchFile: 'missing.patch'},
            {file: 'app/root.tsx', patchFile: 'root.tsx.5e9998.patch'},
          ],
        },
        {
          type: 'PATCH' as const,
          step: '1',
          name: 'README.md',
          description: 'Duplicate name',
          diffs: [],
        },
      ],
      commit: 'abc123',
      llms: {userQueries: [], troubleshooting: []},
    };

    mockLoadRecipe.mockReturnValue(mockRecipe);

    mockExistsSync.mockImplementation((filePath: fs.PathLike) => {
      const pathStr = filePath.toString();
      if (pathStr.endsWith('README.md')) return false;
      if (pathStr.endsWith('.prompt.md')) return false;
      if (pathStr.includes('patches') && pathStr.endsWith('.patch')) {
        return pathStr.includes('root.tsx');
      }
      return true;
    });

    mockReaddirSync.mockImplementation((dirPath: fs.PathOrFileDescriptor) => {
      const pathStr = dirPath.toString();
      if (pathStr.includes('patches')) {
        return [
          {name: 'root.tsx.5e9998.patch', isFile: () => true},
          {name: 'orphaned.patch', isFile: () => true},
        ] as fs.Dirent[];
      }
      return [] as fs.Dirent[];
    });

    const result = validateRecipe({recipeTitle: recipeName});

    expect(result).toBe(false);

    const errorOutput = consoleErrorSpy.mock.calls
      .map((call) => call[0])
      .join('\n');

    expect(errorOutput).toContain(`Recipe '${recipeName}'`);
    expect(errorOutput).toContain('error(s)');

    expect(errorOutput).toContain('validateStepNames');
    expect(errorOutput).toContain('Duplicate step number');

    expect(errorOutput).toContain('validateStepDescriptions');
    expect(errorOutput).toContain('null description');

    expect(errorOutput).toContain('validatePatchFiles');
    expect(errorOutput).toContain('Patch file not found');
    expect(errorOutput).toContain('orphaned.patch');

    expect(errorOutput).toContain('validateReadmeExists');
    expect(errorOutput).toContain('README.md not found');

    expect(errorOutput).toContain('validateLlmPromptExists');
    expect(errorOutput).toContain('LLM prompt file not found');
  });
});

describe('resolveCatalogProtocol', () => {
  let mockExistsSync: Mock;
  let mockReadFileSync: Mock;
  let mockWriteFileSync: Mock;

  const workspaceYaml = `
packages:
  - packages/hydrogen
  - packages/cli
  - templates/skeleton
catalog:
  react: ^18.3.1
  react-dom: ^18.3.1
  '@types/node': ^22
`;

  beforeEach(() => {
    _resetWorkspaceVersionsCache();
    vi.spyOn(console, 'log').mockImplementation(() => {});
    mockExistsSync = vi.spyOn(fs, 'existsSync') as Mock;
    mockReadFileSync = vi.spyOn(fs, 'readFileSync') as Mock;
    mockWriteFileSync = vi.spyOn(fs, 'writeFileSync') as Mock;
    mockWriteFileSync.mockImplementation(() => {});
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('should resolve catalog: references in package.json', () => {
    const workspacePath = path.join(REPO_ROOT, 'pnpm-workspace.yaml');
    const rootPkgPath = path.join(REPO_ROOT, 'package.json');
    const skeletonPkgPath = path.join(TEMPLATE_PATH, 'package.json');

    mockExistsSync.mockReturnValue(true);

    mockReadFileSync.mockImplementation((filePath: string) => {
      if (filePath === workspacePath) return workspaceYaml;
      if (filePath === rootPkgPath) {
        return JSON.stringify({dependencies: {}});
      }
      if (filePath === skeletonPkgPath) {
        return JSON.stringify({
          dependencies: {react: 'catalog:', 'react-dom': 'catalog:'},
          devDependencies: {'@types/node': 'catalog:'},
        });
      }
      // Workspace package.json files for resolving workspace: versions
      if (filePath.includes('packages/hydrogen/package.json')) {
        return JSON.stringify({name: '@shopify/hydrogen', version: '2026.1.0'});
      }
      if (filePath.includes('packages/cli/package.json')) {
        return JSON.stringify({
          name: '@shopify/cli-hydrogen',
          version: '8.5.0',
        });
      }
      return JSON.stringify({});
    });

    resolveCatalogProtocol();

    const writeCalls = mockWriteFileSync.mock.calls;
    const skeletonWrite = writeCalls.find(
      (call: any[]) => call[0] === skeletonPkgPath,
    );

    expect(skeletonWrite).toBeDefined();
    const written = JSON.parse(skeletonWrite![1] as string);
    expect(written.dependencies.react).toBe('^18.3.1');
    expect(written.dependencies['react-dom']).toBe('^18.3.1');
    expect(written.devDependencies['@types/node']).toBe('^22');
  });

  it('should resolve workspace:* references in package.json', () => {
    const workspacePath = path.join(REPO_ROOT, 'pnpm-workspace.yaml');
    const rootPkgPath = path.join(REPO_ROOT, 'package.json');
    const skeletonPkgPath = path.join(TEMPLATE_PATH, 'package.json');

    mockExistsSync.mockReturnValue(true);

    mockReadFileSync.mockImplementation((filePath: string) => {
      if (filePath === workspacePath) return workspaceYaml;
      if (filePath === rootPkgPath) {
        return JSON.stringify({dependencies: {}});
      }
      if (filePath === skeletonPkgPath) {
        return JSON.stringify({
          dependencies: {'@shopify/hydrogen': 'workspace:*'},
        });
      }
      if (filePath.includes('packages/hydrogen/package.json')) {
        return JSON.stringify({name: '@shopify/hydrogen', version: '2026.1.0'});
      }
      if (filePath.includes('packages/cli/package.json')) {
        return JSON.stringify({
          name: '@shopify/cli-hydrogen',
          version: '8.5.0',
        });
      }
      return JSON.stringify({});
    });

    resolveCatalogProtocol();

    const writeCalls = mockWriteFileSync.mock.calls;
    const skeletonWrite = writeCalls.find(
      (call: any[]) => call[0] === skeletonPkgPath,
    );

    expect(skeletonWrite).toBeDefined();
    const written = JSON.parse(skeletonWrite![1] as string);
    expect(written.dependencies['@shopify/hydrogen']).toBe('2026.1.0');
  });

  it('should do nothing when pnpm-workspace.yaml does not exist', () => {
    mockExistsSync.mockReturnValue(false);

    resolveCatalogProtocol();

    expect(mockWriteFileSync).not.toHaveBeenCalled();
  });

  it('should do nothing when no catalog: or workspace: references exist', () => {
    const workspacePath = path.join(REPO_ROOT, 'pnpm-workspace.yaml');
    const rootPkgPath = path.join(REPO_ROOT, 'package.json');

    mockExistsSync.mockReturnValue(true);

    mockReadFileSync.mockImplementation((filePath: string) => {
      if (filePath === workspacePath) return workspaceYaml;
      if (filePath === rootPkgPath) {
        return JSON.stringify({dependencies: {lodash: '^4.0.0'}});
      }
      // Workspace packages
      if (filePath.includes('packages/hydrogen/package.json')) {
        return JSON.stringify({name: '@shopify/hydrogen', version: '2026.1.0'});
      }
      if (filePath.includes('packages/cli/package.json')) {
        return JSON.stringify({
          name: '@shopify/cli-hydrogen',
          version: '8.5.0',
        });
      }
      return JSON.stringify({dependencies: {express: '^4.0.0'}});
    });

    resolveCatalogProtocol();

    expect(mockWriteFileSync).not.toHaveBeenCalled();
  });

  it('should handle catalog:default variant', () => {
    const workspacePath = path.join(REPO_ROOT, 'pnpm-workspace.yaml');
    const rootPkgPath = path.join(REPO_ROOT, 'package.json');
    const skeletonPkgPath = path.join(TEMPLATE_PATH, 'package.json');

    mockExistsSync.mockReturnValue(true);

    mockReadFileSync.mockImplementation((filePath: string) => {
      if (filePath === workspacePath) return workspaceYaml;
      if (filePath === rootPkgPath) {
        return JSON.stringify({dependencies: {}});
      }
      if (filePath === skeletonPkgPath) {
        return JSON.stringify({
          dependencies: {react: 'catalog:default'},
        });
      }
      if (filePath.includes('packages/hydrogen/package.json')) {
        return JSON.stringify({name: '@shopify/hydrogen', version: '2026.1.0'});
      }
      if (filePath.includes('packages/cli/package.json')) {
        return JSON.stringify({
          name: '@shopify/cli-hydrogen',
          version: '8.5.0',
        });
      }
      return JSON.stringify({});
    });

    resolveCatalogProtocol();

    const writeCalls = mockWriteFileSync.mock.calls;
    const skeletonWrite = writeCalls.find(
      (call: any[]) => call[0] === skeletonPkgPath,
    );

    expect(skeletonWrite).toBeDefined();
    const written = JSON.parse(skeletonWrite![1] as string);
    expect(written.dependencies.react).toBe('^18.3.1');
  });
});

describe('withResolvedCatalog', () => {
  let mockExistsSync: Mock;
  let mockReadFileSync: Mock;
  let mockWriteFileSync: Mock;
  const mockedExecFileSync = vi.mocked(execFileSync);

  const workspaceYaml = `
packages:
  - templates/skeleton
catalog:
  react: ^18.3.1
`;

  const skeletonPkgPath = path.join(TEMPLATE_PATH, 'package.json');
  const skeletonPkgJson = JSON.stringify({
    dependencies: {react: 'catalog:'},
  });

  function setupMocksWithCatalogResolution() {
    const workspacePath = path.join(REPO_ROOT, 'pnpm-workspace.yaml');
    const rootPkgPath = path.join(REPO_ROOT, 'package.json');

    mockExistsSync.mockReturnValue(true);
    mockReadFileSync.mockImplementation((filePath: string) => {
      if (filePath === workspacePath) return workspaceYaml;
      if (filePath === rootPkgPath) {
        return JSON.stringify({dependencies: {}});
      }
      if (filePath === skeletonPkgPath) return skeletonPkgJson;
      return JSON.stringify({});
    });
  }

  beforeEach(() => {
    _resetWorkspaceVersionsCache();
    vi.spyOn(console, 'log').mockImplementation(() => {});
    vi.spyOn(console, 'warn').mockImplementation(() => {});
    mockExistsSync = vi.spyOn(fs, 'existsSync') as Mock;
    mockReadFileSync = vi.spyOn(fs, 'readFileSync') as Mock;
    mockWriteFileSync = vi.spyOn(fs, 'writeFileSync') as Mock;
    mockWriteFileSync.mockImplementation(() => {});

    mockedExecFileSync.mockClear();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('should return the result of a sync function', () => {
    setupMocksWithCatalogResolution();
    const result = withResolvedCatalog(() => 42);
    expect(result).toBe(42);
  });

  it('should return the result of an async function', async () => {
    setupMocksWithCatalogResolution();
    const result = await withResolvedCatalog(async () => 'async-result');
    expect(result).toBe('async-result');
  });

  it('should restore modified package.json files after sync success', () => {
    setupMocksWithCatalogResolution();

    withResolvedCatalog(() => 'done');

    expect(mockedExecFileSync).toHaveBeenCalledWith(
      'git',
      expect.arrayContaining(['checkout', '--']),
      expect.objectContaining({cwd: REPO_ROOT}),
    );
  });

  it('should restore modified package.json files after async success', async () => {
    setupMocksWithCatalogResolution();

    await withResolvedCatalog(async () => 'done');

    expect(mockedExecFileSync).toHaveBeenCalledWith(
      'git',
      expect.arrayContaining(['checkout', '--']),
      expect.objectContaining({cwd: REPO_ROOT}),
    );
  });

  it('should restore modified package.json files after sync throw', () => {
    setupMocksWithCatalogResolution();

    expect(() =>
      withResolvedCatalog(() => {
        throw new Error('sync-error');
      }),
    ).toThrow('sync-error');

    expect(mockedExecFileSync).toHaveBeenCalledWith(
      'git',
      expect.arrayContaining(['checkout', '--']),
      expect.objectContaining({cwd: REPO_ROOT}),
    );
  });

  it('should restore modified package.json files after async rejection', async () => {
    setupMocksWithCatalogResolution();

    await expect(
      withResolvedCatalog(async () => {
        throw new Error('async-error');
      }),
    ).rejects.toThrow('async-error');

    expect(mockedExecFileSync).toHaveBeenCalledWith(
      'git',
      expect.arrayContaining(['checkout', '--']),
      expect.objectContaining({cwd: REPO_ROOT}),
    );
  });

  it('should resolve catalog references before executing the function', () => {
    setupMocksWithCatalogResolution();
    let writtenBeforeFn = false;

    withResolvedCatalog(() => {
      // Inside fn, writeFileSync should already have been called by resolveCatalogProtocol
      writtenBeforeFn = mockWriteFileSync.mock.calls.length > 0;
    });

    expect(writtenBeforeFn).toBe(true);
  });
});
